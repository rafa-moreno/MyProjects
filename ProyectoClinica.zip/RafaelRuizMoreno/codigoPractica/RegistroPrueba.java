import java.time.LocalDate;

/**
 * Esta clase almacena la información que tienen los registros
 * de pruebas diagnósticas
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class RegistroPrueba extends Registro
{
    private Tecnico tecnico;
    private PruebaDiag prueba;
    private LocalDate fecha;
    private int numeroRegistro;
    /**
     * Constructor para los objetos de la clase RegistroPrueba
     */
    public RegistroPrueba(String dniPaciente, String nombrePaciente)
    {
        super(dniPaciente, nombrePaciente);
    }
    
    /**
     * Devuelve el tecnico asignado al registro
     * 
     * @return     El técnico asignado
     */
    public Empleado getTecnico()  {  return tecnico;  }
    
    /**
     *  Establece un nuevo ténico al registro
     *  
     *  @param tecnico Nuevo técnico asignado al registro
     */
    public void setTecnico(Tecnico tecnico){ this.tecnico = tecnico;}
    
    /**
     * Devuelve la prueba asignada al registro
     * 
     * @return La prueba asignada al registro
     */
    public PruebaDiag getPrueba(){ return prueba; }
    
    /**
     * Establece una nueva prueba en el registro
     * 
     * @param prueba Nueva prueba asignada al registro
     */
    public void setPrueba(PruebaDiag prueba){ this.prueba = prueba;}
    
    /**
     * Establece una nueva fecha para el registro
     * 
     * @param fecha Nueva fecha para el registro 
     */
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    
    /**
     * Devuelve la fecha del registro
     * 
     * @return La fecha del registro de prueba
     */
    public LocalDate getFecha(){ return fecha; }
    
    /**
     * Devuelve el numero del registro, único para cada uno de ellos
     * 
     * @return El numero de registro
     */
    public int getNumeroRegistro(){ return numeroRegistro;}
    
    /**
     * Establece un nuevo numero para el registro, debe ser único para cada 
     * uno de ellos
     * 
     * @param numero El nuevo numero asignado al registro
     */
    public void setNumeroRegistro(int numero){ numeroRegistro = numero;}
    
    /**
     * Imprime en pantalla la información del registro de prueba
     * diagóstica, tanto del paciente, como enfermero y técnicos que 
     * están asignados. También muestra si la prueba está realizada o no, 
     * y sus resultados
     */
    public void printInfoRegistroPruebas(){
        if(prueba.getRealizada()){
            System.out.println("-----------------------------");
            System.out.println("      REGISTRO DE PRUEBA     ");
            System.out.println("Numeración: "+ getNumeroRegistro());
            System.out.println("Paciente: "+ getNombrePaciente());
            System.out.println("DNI del paciente: " + getDniPaciente());
            System.out.println();
            prueba.printInfoPrueba();
            System.out.println("Realizada el día "+ getFecha() + " por el enfermero: " + getEnfermero().getNombre() + " y el técnico " + tecnico.getNombre());
            System.out.println("-----------------------------");
             
        } else {
            System.out.println("-----------------------------");
            System.out.println("      REGISTRO DE PRUEBA     ");
            System.out.println("Numeración: "+ getNumeroRegistro());
            System.out.println("Paciente: "+ getNombrePaciente());
            System.out.println("DNI del paciente: " + getDniPaciente());
            System.out.println("Registro de prueba");
            System.out.println(prueba.getNombrePrueba());
            System.out.println();
            System.out.println("Prevista para el día "+ getFecha() + " por el enfermero: " + getEnfermero().getNombre() + " y el técnico " + tecnico.getNombre());
            System.out.println("-----------------------------");
        }
        
    }
}
