
/**
 * Esta clase representa a cada técnico de 
 * la clínica
 * @author Rafael Ruiz Moreno 
 * @version 0.1
 */
public class Tecnico extends Empleado
{
      private String tipoEmpleado;
    
    /**
     * Constructor de los objetos de la clase Tecnico
    */
    public Tecnico(String dni, String nombre, int edad, boolean sexo)
    {
        super(dni, nombre, edad, sexo);
        tipoEmpleado = "Técnico";

    }
    
    /**
     * Devuelve el tipo de empleado
     * 
     * @return El tipo de empleado del tecnico
     */
    public String getTipoEmpleado(){ return tipoEmpleado; }
    
    /**
     * Imprime en pantalla la información del empleado,
     * lo que incluye tipo de empleado y sus datos personales
     */
    public void printEmpleadoInfo(){
        System.out.println("Técnico: " + getPersonInfo());
    }
}
