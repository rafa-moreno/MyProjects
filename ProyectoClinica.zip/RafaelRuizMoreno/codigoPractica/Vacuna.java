
/**
 * Clase que almacena la información común a todas
 * las vacunas que hay en el sistema
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
abstract class Vacuna
{
    private String nombreVacuna;

    /**
     * Constructor de los objetos de la clase Vacuna
     */
    public Vacuna(String nombre)
    {
        nombreVacuna = nombre;
    }
    
    /**
     * Devuelve el nombre de la vacuna
     * 
     * @return Nombre de la vacuna
     */
    public String getNombreVacuna(){ return nombreVacuna; }
    
    /**
     * Devuelve el número de dosis de la vacuna
     * 
     * @return Número de dosis de la vacuna
     */
    abstract public int getNumeroDosis();
}
