import java.util.Scanner;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Random;
import java.util.*;
/**
 * Clase dedicada a la gestión de todos los datos relacionados
 * con la clínica covid-19, incluyendo stock de vacunas, 
 * pacientes y empleados, así como su relacion con las vacunas
 * y pruebas diagnósticas asignadas y realizadas
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class Clinica
{
    private ArrayList<Vacuna> stockVacunas;                     //stock de las vacunas de la clinica
    private ArrayList<Paciente> pacientes;                      //lista de pacientes registrados en el sistema
    private ArrayList<Paciente> listaPacientesVacunacion;       //lista de pacientes que han ido a la clinica a solicitar la vacuna
    private ArrayList<Empleado> empleados;                      //lista de empleados registrados en el sistema
    private Empleado empleadoActual;                            //variable auxiliar que indicara el tipo de empleado que está ejecutando la aplicación
    private Random numeroRandom;                                
    private Scanner scanner;
    private boolean finish;
    /**
     * Constructor de los objetos de clase Clinica
     */
    public Clinica()
    {
        stockVacunas = new ArrayList<>();       
        pacientes    = new ArrayList<>();       
        empleados    = new ArrayList<>();       
        listaPacientesVacunacion = new ArrayList<>();    
        scanner = new Scanner(System.in);       
        numeroRandom = new Random();
        finish = false;
        empleadoActual = null;
    }
    
    /**
     * Empieza el programa, en pantalla aparece la bienvenida y después se
     * solicita el DNI de la persona, tras esto el programa automáticamente
     * le muestra el menú correspondiente a su tipo de empleado.
     * El programa solo termina si el usuario escribe "salir" en el menú inicial.
     */
    public void start()
    {        
        iniciarDatos();
        printBienvenida();
        String entrada;
        while(!finish){

            entrada = scanner.nextLine();
            if(!quiereSalir(entrada)){
                try{
                for(Empleado empleado : empleados){
                    if(empleado.getDNI().equals(entrada)){
                        empleadoActual = empleado;
                        if(empleadoActual instanceof Administrador){
                            System.out.println("Bienvenido/a "+ empleadoActual.getNombre());                
                            menuAdmin();
                            empleadoActual = null;
                            printBienvenida();
                        }
                        else if (empleadoActual instanceof Enfermero){
                            System.out.println("Bienvenido/a "+ empleadoActual.getNombre());
                            menuEnfermero();
                            empleadoActual = null;
                            printBienvenida();
                        }
                        else if (empleadoActual instanceof Tecnico){
                            System.out.println("Bienvenido/a "+ empleadoActual.getNombre());
                            menuTecnico();
                            empleadoActual = null;
                            printBienvenida();
                        }
                    }
                }
            }
                catch(Exception e){   }    // Con este try-catch se evita una excepción al cambiar el listado de empleados al dar de alta/baja a uno de ellos.
                
            } else {
                finish = true;
            }
        }
        
        printDespedida();
        finish = false;
    }
    
    /**
     * Inicialización de datos previos
     */
    
    private void iniciarDatos(){
        Empleado admin1 = new Administrador("2594895842T", "Rafael Ruiz Moreno", 21, false);
        Empleado enfermero1 = new Enfermero("2857129489G", "Juan Jose Santos", 41, false);
        Empleado enfermero2 = new Enfermero("1540151209Y", "Maria José Jiménez", 29, true);
        Empleado tecnico1 = new Tecnico("2351562582K", "Julián López", 45, false);
        Empleado tecnico2 = new Tecnico("2675102015I", "Manuel Ruiz", 38, false);
        empleados.add(admin1);
        empleados.add(enfermero1);
        empleados.add(enfermero2);
        empleados.add(tecnico1);
        empleados.add(tecnico2);
        
        
        Paciente paciente1 = new Paciente("2869485424E", "Manuel Pérez", 29, false);
        Paciente paciente2 = new Paciente("2661456278P", "María García", 34, true);
        Paciente paciente3 = new Paciente("2587120050G", "Luis Ruiz", 21, false);
        Paciente paciente4 = new Paciente("2859912451R", "Ángela Gómez", 22, true);
        Paciente paciente5 = new Paciente("2581238541L", "Pedro Moreno", 28, false);
        pacientes.add(paciente1);
        pacientes.add(paciente2);
        pacientes.add(paciente3);
        pacientes.add(paciente4);
        pacientes.add(paciente5);
        PCR pcr1 = new PCR();
        pcr1.setRealizada(true);
        RegistroPrueba registroPCR = new RegistroPrueba(paciente1.getDNI(), paciente1.getNombre());
        registroPCR.setPrueba(pcr1);
        registroPCR.setFecha(LocalDate.parse("2021-02-15"));
        registroPCR.setEnfermero((Enfermero)enfermero1);
        registroPCR.setTecnico((Tecnico)tecnico1);
        registroPCR.setNumeroRegistro(2104);
        paciente1.getHistorialPaciente().getRegistrosP().add(registroPCR);
    
    }
    
    /**
     *  Mensaje de bienvenida, mostrado cada vez que se inicia el programa
     *  o al salir del menú de empleado.
     */
    
    private void printBienvenida(){
        System.out.println("-----------------------------------------------------------");
        System.out.println("     Bienvenido/a al sistema de gestión de la clínica        ");
        System.out.println("               (Para salir escriba : ``salir``)            ");
        System.out.println();
        System.out.println("       Porfavor introduzca su DNI para identificarle       ");
        System.out.println();
        System.out.println("-----------------------------------------------------------");
    }
    
    /**
     *  Mensaje de despedida. Mostrado una vez que el usuario sale del sistema.
     */
    
    private void printDespedida(){
        
        System.out.println();
        System.out.println("---------------------------------");
        System.out.println("   Gracias, hasta la próxima     ");
        System.out.println("---------------------------------");
        System.out.println();
    }
    
    /**
     *  Ejecución del menú para administradores, en función del comando
     *  introducido, se procederá con el método correspondiente.
     *  Para salir de este menú el usuario tendrá que escribir "salir" 
     *  y será llevado al menú principal
     */
    
    private void menuAdmin(){
        
        String entradaMenuAdmin = "";
        while(!quiereSalir(entradaMenuAdmin)){
            listaAccionesAdmin();
            entradaMenuAdmin = scanner.nextLine();
            switch(entradaMenuAdmin.toLowerCase()){
                case "ap":
                altaPaciente();
                break;
                            
                case "ae":
                altaEmpleado();
                break;
                            
                case "lp":
                listadoPacientes();
                break;
                            
                case "le":
                listadoEmpleados();
                break;
                            
                case "bp":
                bajaPaciente();
                break;
                            
                case "be":
                bajaEmpleado();
                break;
                            
                case "mp":
                modificarPaciente();
                break;
                            
                case "me":
                modificarEmpleado();
                break;
                            
                case "dp":
                datosPersona();
                break;
                            
                case "cs":
                consultaStockVacunas();
                break;
                            
                case "as":
                actualizaStockVacunas();
                break;
                            
                case "rs":
                resetearStockVacunas();
                break; 
                            
                case "ad":
                asignarPruebaDiagnostica();
                break;
                            
                case "rp":
                introducirDatosRegistroPrueba(empleadoActual);
                break;
                            
                case "ip":
                incluirPacienteListaVacunación();
                break;
                            
                case "av":
                asignarVacunas();
                break;
                            
                case "ac":
                actualizarDatosVacuna(empleadoActual);
                break;
                            
                case "vv":
                printListaPacientesOrdenada();                            
                break;
                            
                case "salir":
                entradaMenuAdmin = "salir";
                break;
                            
                default:
                System.out.println("Introduzca un comando válido");
            }
        }
        
    }
    
    /**
     *  Ejecución del menú para enfermeros, en función del comando
     *  introducido, se procederá con el método correspondiente.
     *  Para salir de este menú el usuario tendrá que escribir "salir" 
     *  y será llevado al menú principal
     */
    
    private void menuEnfermero(){     
        String entradaMenuEnfermero = "";
        while(!quiereSalir(entradaMenuEnfermero)){
            listaAccionesEnfermero();
            entradaMenuEnfermero = scanner.nextLine();
            switch(entradaMenuEnfermero.toLowerCase()){
                       
                case "lp":
                listadoPacientesAsignadosPruebas(empleadoActual);
                break;
                    
                case "lv":
                listadoPacientesAsignadosVacunas(empleadoActual);
                break;
                    
                case "lt":
                listadoPacientesAsignadosPruebas(empleadoActual);
                listadoPacientesAsignadosVacunas(empleadoActual);
                break;
                    
                case "rp":
                introducirDatosRegistroPrueba(empleadoActual);
                break;
                            
                case "ac":
                actualizarDatosVacuna(empleadoActual);
                break;
                            
                            
                case "salir":
                entradaMenuEnfermero = "salir";
                break;
                            
                default:
                System.out.println("Introduzca un comando válido");
            }  
        }
        
    }
    
    /**
     *  Ejecución del menú para técnicos, en función del comando
     *  introducido, se procederá con el método correspondiente.
     *  Para salir de este menú el usuario tendrá que escribir "salir" 
     *  y será llevado al menú principal
     */
    
    private void menuTecnico(){       
        String entradaMenuTecnico = "";
        while(!quiereSalir(entradaMenuTecnico)){
            listaAccionesTecnico();
            entradaMenuTecnico = scanner.nextLine();
            switch(entradaMenuTecnico.toLowerCase()){
                       
                case "lp":
                listadoPacientesAsignadosPruebas(empleadoActual);
                break;
                    
                case "rp":
                introducirDatosRegistroPrueba(empleadoActual);
                break;   
                            
                case "salir":
                entradaMenuTecnico = "salir";
                break;
                            
                default:
                System.out.println("Introduzca un comando válido");
            }
        }
        
    }
    
    /**
     * Se imprime en pantalla la lista de acciones que puede desarrollar
     * cada administrador
     */
    
    private void listaAccionesAdmin(){
        System.out.println("-----------------------------------------------------------");
        System.out.println("            Lista de acciones de administrador           ");
        System.out.println();
        System.out.println("       Listado de Pacientes (LP)                           "); 
        System.out.println("       Listado de Empleados (LE)                           ");
        System.out.println("       Alta Pacientes (AP)                                 "); 
        System.out.println("       Alta Empleados (AE)                                 ");
        System.out.println("       Baja Pacientes (BP)                                 "); 
        System.out.println("       Baja Empleados (BE)                                 ");
        System.out.println("       Modificar Pacientes (MP)                            "); 
        System.out.println("       Modificar Empleados (ME)                            ");
        System.out.println("       Datos de Empleado o Paciente (DP)                   "); 
        System.out.println("       Consultar Stock Vacunas (CS)                         ");
        System.out.println("       Actualizar Stock Vacunas (AS)                       "); 
        System.out.println("       Poner a cero Stock Vacunas (RS)                       ");
        System.out.println("       Incluir a Paciente en lista de espera para vacunación (IP)");
        System.out.println("       Asignación Pruebas Diagnosticas (AD)                ");
        System.out.println("       Asignación Vacunas(AV)                              ");
        System.out.println("       Actualizar resultados Pruebas Diagnosticas (RP)     ");
        System.out.println("       Actualizar vacunación de paciente (AC)              ");
        System.out.println("       Visualizar planificación tentativa de vacunas (VV)  ");
        System.out.println("       Para volver al menú principal escriba ``salir``                    ");
        System.out.println();
        System.out.println("-----------------------------------------------------------");
    }
    
    /**
     * Se imprime en pantalla la lista de acciones que puede desarrollar
     * cada enfermero
     */
    
    private void listaAccionesEnfermero(){
        System.out.println("-----------------------------------------------------------");
        System.out.println("            Lista de acciones de enfermero           ");
        System.out.println();
        System.out.println("       Listado de Pacientes Asignados para Pruebas Diagnósticas (LP)                 "); 
        System.out.println("       Listado de Pacientes Asignados para Vacunaciones (LV)                 ");
        System.out.println("       Listado de Pacientes Asignados Total (LT)                "); 
        System.out.println("       Actualizar resultados Pruebas Diagnosticas de sus pacientes asignados (RP)     ");
        System.out.println("       Actualizar vacunación de sus pacientes asignados (AC)              ");
        System.out.println("       Para volver al menú principal escriba ``salir``                    ");
        System.out.println();
        System.out.println("-----------------------------------------------------------");
    }
    
    /**
     * Se imprime en pantalla la lista de acciones que puede desarrollar
     * cada técnico
     */
    
    private void listaAccionesTecnico(){
        System.out.println("-----------------------------------------------------------");
        System.out.println("            Lista de acciones de técnico           ");
        System.out.println();
        System.out.println("       Listado de Pacientes Asignados para Pruebas (LP)                 "); 
        System.out.println("       Actualizar resultados Pruebas Diagnosticas de sus pacientes asignados (RP)     ");
        System.out.println("       Para volver al menú principal escriba ``salir``                    ");
        System.out.println();
        System.out.println("-----------------------------------------------------------");
    }
    
    /**
     * Con este método se añade a la lista de pacientes del sistema
     * un nuevo paciente, introduciendo todos los datos necesarios,
     * que se irán pidiendo y comprobando
     */
    
    private void altaPaciente(){
         System.out.println("Introduzca los datos del nuevo paciente");
         System.out.println("Nombre: ");
         String nombrePaciente = scanner.nextLine();
         System.out.println("DNI: ");
         String dniPaciente = scanner.nextLine();
         for(Persona persona : pacientes){
             if(persona.getDNI().equalsIgnoreCase(dniPaciente)){
                 System.out.println("Ya hay una persona registrada con ese DNI");
                 return;
            }
         }
         for(Persona persona : empleados){
             if(persona.getDNI().equalsIgnoreCase(dniPaciente)){
                 System.out.println("Ya hay una persona registrada con ese DNI");
                 return;
            }
         }
         System.out.println("Edad: ");
         String edadPaciente = scanner.nextLine();
         while(Integer.parseInt(edadPaciente) < 3 && Integer.parseInt(edadPaciente) > 110){
             System.out.println("La edad debe estar comprendida entre 3 y 110 años");
             edadPaciente = scanner.nextLine();
         }
         System.out.println("Sexo: ");
         String sexoPaciente = scanner.nextLine();
                           
         if(sexoPaciente.equalsIgnoreCase("Hombre")){
             Paciente nuevoPaciente = new Paciente (dniPaciente, nombrePaciente, Integer.parseInt(edadPaciente), false);
             pacientes.add(nuevoPaciente);
         } else if (sexoPaciente.equalsIgnoreCase("Mujer")){
             Paciente nuevoPaciente = new Paciente (dniPaciente, nombrePaciente, Integer.parseInt(edadPaciente), true);
             pacientes.add(nuevoPaciente);
         } else {
             System.out.println("Sexo incorrecto ");
            }
    }
    
    /**
     * Con este método se añade a la lista de empleados del sistema
     * un nuevo empleado, introduciendo todos los datos necesarios,
     * que se irán pidiendo y comprobando
     */
    
    private void altaEmpleado(){
         System.out.println("Introduzca los datos del nuevo empleado");
         System.out.println("Nombre: ");
         String nombreEmpleado = scanner.nextLine();
         System.out.println("DNI: ");
         String dniEmpleado = scanner.nextLine();
         for(Persona persona : pacientes){
             if(persona.getDNI().equalsIgnoreCase(dniEmpleado)){
                 System.out.println("Ya hay una persona registrada con ese DNI");
                 return;
            }
         }
         for(Persona persona : empleados){
             if(persona.getDNI().equalsIgnoreCase(dniEmpleado)){
                 System.out.println("Ya hay una persona registrada con ese DNI");
                 return;
            }
         }
         System.out.println("Edad: ");
         String edadEmpleado = scanner.nextLine();
         while(Integer.parseInt(edadEmpleado) < 3 && Integer.parseInt(edadEmpleado) > 110){
             System.out.println("La edad debe estar comprendida entre 3 y 110 años");
             edadEmpleado = scanner.nextLine();
         }
         System.out.println("Sexo: ");
         String sexoEmpleado = scanner.nextLine();
         System.out.println("Tipo de empleado: ");
         String tipoEmpleado = scanner.nextLine();
         
         switch(tipoEmpleado){
                 case "administrador":
                 case "Administrador":
                 case "admin":
                 case "Admin":
                 if(sexoEmpleado.equalsIgnoreCase("Hombre")){
                     Empleado nuevoEmpleado = new Administrador (dniEmpleado, nombreEmpleado, Integer.parseInt(edadEmpleado), false);
                     empleados.add(nuevoEmpleado);
                 } else if(sexoEmpleado.equalsIgnoreCase("Mujer")){
                     Empleado nuevoEmpleado = new Administrador (dniEmpleado, nombreEmpleado, Integer.parseInt(edadEmpleado), true);
                     empleados.add(nuevoEmpleado);
                 } else {
                     System.out.println("Sexo incorrecto");
                     return;
                 }
                 break;
             
                 case "enfermero":
                 case "Enfermero":
                 if(sexoEmpleado.equalsIgnoreCase("Hombre")){
                     Empleado nuevoEmpleado = new Enfermero (dniEmpleado, nombreEmpleado, Integer.parseInt(edadEmpleado), false);
                     empleados.add(nuevoEmpleado);
                 } else if(sexoEmpleado.equalsIgnoreCase("Mujer")){
                     Empleado nuevoEmpleado = new Enfermero (dniEmpleado, nombreEmpleado, Integer.parseInt(edadEmpleado), true);
                     empleados.add(nuevoEmpleado);
                 } else {
                     System.out.println("Sexo incorrecto");
                     return;
                 }
                 break;
             
                 case "tecnico":
                 case "Tecnico":
                 case "técnico":
                 case "Técnico":
                 if(sexoEmpleado.equalsIgnoreCase("Hombre")){
                     Empleado nuevoEmpleado = new Tecnico (dniEmpleado, nombreEmpleado, Integer.parseInt(edadEmpleado), false);
                     empleados.add(nuevoEmpleado);
                 } else if(sexoEmpleado.equalsIgnoreCase("Mujer")){
                     Empleado nuevoEmpleado = new Tecnico (dniEmpleado, nombreEmpleado, Integer.parseInt(edadEmpleado), true);
                     empleados.add(nuevoEmpleado);
                 } else {
                     System.out.println("Sexo incorrecto");
                 }
                 break;
                 
                 default:
                 System.out.println("Tipo de empleado incorrecto");
             }  
    }
    
    /**
     * Con este método se elimina de la lista de pacientes al 
     * paciente que tenga el DNI introducido, en el caso de 
     * que esté en la lista
     */
    
    private void bajaPaciente(){
        System.out.println("¿Qué paciente desea dar de baja?");
        listadoPacientes();
        System.out.println("(Introduzca el DNI de la persona)");
        String darDeBaja = scanner.nextLine();
        
        for(Paciente paciente : pacientes){
            if(paciente.getDNI().equalsIgnoreCase(darDeBaja)){
                pacientes.remove(paciente);
                return;
            }
        }
        System.out.println("No hay ningún paciente con ese DNI");

    }
    
    /**
     * Con este método se elimina de la lista de empleados al 
     * empleado que tenga el DNI introducido, en el caso de 
     * que esté en la lista
     */
    
    private void bajaEmpleado(){
        System.out.println("¿Qué empleado desea dar de baja?");
        listadoEmpleados();
        System.out.println("(Introduzca el DNI de la persona)");
        String darDeBaja = scanner.nextLine();
        
        for(Empleado empleado : empleados){
            if(empleado.getDNI().equalsIgnoreCase(darDeBaja)){
                if(empleado instanceof Administrador){
                    System.out.println("No puedes dar de baja a otro administrador");
                    return;
                } else{
                    empleados.remove(empleado);
                    return;
            }
            } 
        }
        System.out.println("No hay ningún empleado con ese DNI");

    }
    
    /**
     * Con este método se modifica el dato que se quiera cambiar del
     * paciente indicado
     */
    
    private void modificarPaciente(){
        System.out.println("¿Qué paciente desea modificar?");
        listadoPacientes();
        System.out.println("(Introduzca el DNI de la persona)");
        String darDeBaja = scanner.nextLine();
        
        for(Paciente paciente : pacientes){
            if(paciente.getDNI().equalsIgnoreCase(darDeBaja)){
                System.out.println("¿Qué dato desea modificar? (DNI, nombre, edad, sexo)");
                String datoModificar = scanner.nextLine();
                
                switch(datoModificar){
                     case "DNI":
                     case "dni":
                     System.out.println("Introduzca el nuevo DNI");
                     String nuevoDNI = scanner.nextLine();
                     for(Persona persona : pacientes){
                         if(persona.getDNI().equalsIgnoreCase(nuevoDNI)){
                             System.out.println("Ya hay una persona registrada con ese DNI");
                             return;
                        }
                     }
                     for(Persona persona : empleados){
                         if(persona.getDNI().equalsIgnoreCase(nuevoDNI)){
                             System.out.println("Ya hay una persona registrada con ese DNI");
                             return;
                        }
                     }
                     paciente.setDNI(nuevoDNI);
                     break;
                 
                     case "Nombre":
                     case "nombre":
                     System.out.println("Introduzca el nuevo nombre");
                     paciente.setNombre(scanner.nextLine());
                     break;
                 
                     case "Edad":
                     case "edad":
                     System.out.println("Introduzca la nueva edad");
                     String edadPaciente = scanner.nextLine();
                     while(Integer.parseInt(edadPaciente) < 3 && Integer.parseInt(edadPaciente) > 110){
                         System.out.println("La edad debe estar comprendida entre 3 y 110 años");
                         edadPaciente = scanner.nextLine();
                        }
                     paciente.setEdad(Integer.parseInt(edadPaciente));
                     
                     break;
                 
                     case "Sexo":
                     case "sexo":
                     System.out.println("Introduzca el nuevo sexo");
                     if(scanner.nextLine().equalsIgnoreCase("hombre")){
                            paciente.setSexo(false);
                        } else if(scanner.nextLine().equalsIgnoreCase("mujer")){
                            paciente.setSexo(true);
                        } else {
                            System.out.println("Sexo incorrecto ");   
                        }
                     break;
                     
                     default:
                     System.out.println("Dato erróneo");
                     }
                return;
            }
        }
        System.out.println("No hay ningún paciente con ese DNI");

    }
    
    /**
     * Con este método se modifica el dato que se quiera cambiar del
     * empleado indicado
     */
    
    private void modificarEmpleado(){
        System.out.println("¿Qué empleado desea modificar?");
        listadoEmpleados();
        System.out.println("(Introduzca el DNI de la persona)");
        String darDeBaja = scanner.nextLine();
        
        for(Empleado empleado : empleados){
            if(empleado.getDNI().equalsIgnoreCase(darDeBaja)){
                System.out.println("¿Qué dato desea modificar? (DNI, nombre, edad, sexo)");
                String datoModificar = scanner.nextLine();
                switch(datoModificar){
                 case "DNI":
                 case "dni":
                    System.out.println("Introduzca el nuevo DNI");
                    String nuevoDNI = scanner.nextLine();
                    for(Persona persona : pacientes){
                         if(persona.getDNI().equalsIgnoreCase(nuevoDNI)){
                             System.out.println("Ya hay una persona registrada con ese DNI");
                             return;
                        }
                     }
                     for(Persona persona : empleados){
                         if(persona.getDNI().equalsIgnoreCase(nuevoDNI)){
                             System.out.println("Ya hay una persona registrada con ese DNI");
                             return;
                        }
                    }
                    empleado.setDNI(nuevoDNI);
                 break;
                 
                 case "Nombre":
                 case "nombre":
                 System.out.println("Introduzca el nuevo nombre");
                 empleado.setNombre(scanner.nextLine());
                 break;
                 
                 case "Edad":
                 case "edad":
                 System.out.println("Introduzca la nueva edad");
                 String edadEmpleado = scanner.nextLine();
                 while(Integer.parseInt(edadEmpleado) < 3 && Integer.parseInt(edadEmpleado) > 110){
                     System.out.println("La edad debe estar comprendida entre 3 y 110 años");
                     edadEmpleado = scanner.nextLine();
                 }
                 empleado.setEdad(Integer.parseInt(edadEmpleado));
                 break;
                 
                 case "Sexo":
                 case "sexo":
                 System.out.println("Introduzca el nuevo sexo");
                 if(scanner.nextLine().equalsIgnoreCase("hombre")){
                     empleado.setSexo(false);
                    } else if(scanner.nextLine().equalsIgnoreCase("mujer")){
                        empleado.setSexo(true);
                    } else {
                      System.out.println("Sexo incorrecto ");   
                    }
                 break;
                 
                 
                 default:
                 System.out.println("Dato erróneo");
                }
                return;
            }
        }
        System.out.println("No hay ningún empleado con ese DNI");

    }
    
    /**
     * Se imprime el listado de todos los pacientes registrados
     * en el sistema
     */
    
    private void listadoPacientes(){
        System.out.println("            PACIENTES        ");
        for(Paciente paciente : pacientes){
            paciente.printPacienteInfo();
            System.out.println();
        }

    }
    
    /**
     * Se imprime el listado de todos los empleados registrados
     * en el sistema
     */
    
    private void listadoEmpleados(){
        System.out.println("          ADMINISTRADORES/AS        ");
        for(Empleado empleado : empleados){
            if(empleado instanceof Administrador){
                empleado.printEmpleadoInfo();
                System.out.println();
            }
        }
        listadoEnfermeros();
        listadoTecnicos();
                
    }
    
    /**
     * Se imprime el listado de todos los enfermeros registrados
     * en el sistema
     */
    
    private void listadoEnfermeros(){
        System.out.println("            ENFERMEROS/AS        ");
        for(Empleado empleado : empleados){
            if(empleado instanceof Enfermero){
                empleado.printEmpleadoInfo();
                System.out.println();
            }
        }
    }
    
    /**
     * Se imprime el listado de todos los técnicos registrados
     * en el sistema
     */
    
    private void listadoTecnicos(){
        System.out.println("             TÉCNICOS/AS        ");
        for(Empleado empleado : empleados){
            if(empleado instanceof Tecnico){
                empleado.printEmpleadoInfo();
                System.out.println();
            }
        }
    }
    
    /**
     * Se imprime el listado de todos los pacientes asignados para
     * las pruebas diagnósticas del empleado que solicita el método
     * 
     * @param emp Empleado del que se imprimirá el listado de pacientes asignados
     */
    
    private void listadoPacientesAsignadosPruebas(Empleado emp){
        ArrayList<Paciente> listaPacientesPruebas = emp.getListaPacientesPruebas();
        for(Paciente paciente : listaPacientesPruebas){
            
            paciente.getHistorialPaciente().printDatosHistorial();
        }
    }
    
    /**
     * Se imprime el listado de todos los pacientes asignados para
     * las vacunaciones del empleado que solicita el método
     * 
     * @param emp Empleado del que se imprimirá el listado de pacientes asignados
     */
    
    private void listadoPacientesAsignadosVacunas(Empleado emp){
        ArrayList<Paciente> listaPacientesVacunas = emp.getListaPacientesVacunas();
        for(Paciente paciente : listaPacientesVacunas){
            
            printInfoVacunaPaciente(paciente);
        }
    }
    
    /**
     * Lista de pacientes a la espera de ser vacunados
     * ordenados en función de su edad
     */
    private void printListaPacientesOrdenada(){
        
        Collections.sort(listaPacientesVacunacion);
        System.out.println("Pacientes en lista de vacunación ordenados según su edad");
        for(Paciente paciente : listaPacientesVacunacion){
            paciente.printPacienteInfo();
            printInfoVacunaPaciente(paciente);
            System.out.println();
        }
    }
    
    /**
     * Se imprime en pantalla toda la información de la persona que 
     * tenga el DNI introducido por el usuario, en caso de que coincida
     * con el de algún empleado o paciente. Tanto para empleados como para pacientes
     * mostrará sus datos personales, de empleados mostrará los registros de pruebas diagnósticas y/o
     * vacunas asignadas o realizadas de todos los pacientes que tenga asignado.
     * En caso de los pacientes aparte de los datos, mostrará sus registros de pruebas y 
     * su registro de vacuna en caso de que tenga.
     */
    private void datosPersona(){
        System.out.println("Indique el DNI de la persona que desea buscar");

        String dniPersona = scanner.nextLine();
        for(Empleado empleado : empleados){
            if(empleado.getDNI().equals(dniPersona)){
                empleado.printEmpleadoInfo();
                empleado.getHistorialEmpleado().printDatosHistorial();
                ArrayList<Paciente> listaPacientesVacunaEmpleado = empleado.getListaPacientesVacunas();
                for(Paciente paciente : listaPacientesVacunaEmpleado){
                    printInfoVacunaPaciente(paciente);
                }

                return;
            }
        }
        
        for(Paciente paciente : pacientes){
            if(paciente.getDNI().equals(dniPersona)){
                paciente.printPacienteInfo();
                paciente.getHistorialPaciente().printDatosHistorial();
                printInfoVacunaPaciente(paciente);
                return;
            }
        }
        
        System.out.println("No hay ninguna persona guardada con ese DNI");
    }
    
    /**
     * Con este método se imprime en pantalla el número de vacunas que hay
     * disponibles en ese momento, de los tres tipos y totales
     */
    private void consultaStockVacunas(){
        int numeroVacunasModerna = 0;
        int numeroVacunasPfizer = 0;
        int numeroVacunasJJ = 0;
        System.out.println("El número de vacunas disponibles en el stock son: ");
        System.out.println();
        for(Vacuna vacuna : stockVacunas){
            if(vacuna instanceof VacunaModerna){
                numeroVacunasModerna++;
            } else if (vacuna instanceof VacunaPfizer){
                numeroVacunasPfizer++;
            } else if (vacuna instanceof VacunaJJ){
                numeroVacunasJJ++;
            }
        }
        System.out.println(numeroVacunasModerna + " vacunas desarrolladas por Moderna");
        System.out.println(numeroVacunasPfizer + " vacunas desarrolladas por Pfizer");
        System.out.println(numeroVacunasJJ + " vacunas desarrolladas por Johnson&Johnson");
        System.out.println("Vacunas totales: "+ stockVacunas.size());
      
    }
    
    /**
     * Se solicita el número de vacunas de cada uno de los tipos disponibles en la clínica
     * y se va guardando en la lista del stock de vacunas
     */
    
    private void actualizaStockVacunas(){
        int numeroVacunasModerna, numeroVacunasPfizer, numeroVacunasJJ;
         
        System.out.println("Indique el número de vacunas desarrolladas por Moderna que desea incluir en el stock");
        numeroVacunasModerna = Integer.parseInt(scanner.nextLine());
        System.out.println("Indique el número de vacunas desarrolladas por Pfizer que desea incluir en el stock");
        numeroVacunasPfizer = Integer.parseInt(scanner.nextLine());
        System.out.println("Indique el número de vacunas desarrolladas por Johnson&Johnson que desea incluir en el stock");
        numeroVacunasJJ = Integer.parseInt(scanner.nextLine());
        
        for(int i=0; i<numeroVacunasModerna; i++){
            VacunaModerna vacModerna = new VacunaModerna();
            stockVacunas.add(vacModerna);
        }
        
        for(int i=0; i<numeroVacunasPfizer; i++){
            VacunaPfizer vacPfizer = new VacunaPfizer();
            stockVacunas.add(vacPfizer);
        }
        
        for(int i=0; i<numeroVacunasJJ; i++){
            VacunaJJ vacJJ = new VacunaJJ();
            stockVacunas.add(vacJJ);
        }
        
        System.out.println("Stock actualizado");

    }
    
    /**
     * Con este método se pone el stock de vacunas a cero
     */
    
    private void resetearStockVacunas(){
        stockVacunas.clear();
        System.out.println("Stock reseteado");

    }
    
    /**
     * Método con el que se asignará una prueba diagnóstica a un paciente
     * y a cada empleado que vaya a intervenir en dicha prueba
     * A lo largo del método se establecen las comprobaciones temporales necesarias,
     * tanto para que entre cada prueba pase el tiempo que tiene que pasar, si procede, como 
     * para que cada enfermero y técnico no realice más de 5 o 4 pruebas por semana, respectivamente.
     * Tras asignar todos los datos necesarios correctamente se guardá el registro de la prueba diagnóstica
     * a paciente, enfermero y técnico
     */
    
    private void asignarPruebaDiagnostica(){
        int numeroPruebasEnfermeroUltimaSemana = 0;   // variable con la que se comprobará que cada enfermero no realice más de 5 pruebas por semana
        int numeroPruebasTecnicoUltimaSemana = 0;     // variable con la que se comprobará que cada técnico no realice más de 4 pruebas por semana
        System.out.println("Lista de pacientes");
        listadoPacientes();
        System.out.println("(Introduzca el DNI del paciente)");
        String dniPacientePrueba = scanner.nextLine();
        
        for(Paciente paciente : pacientes){
            if(paciente.getDNI().equals(dniPacientePrueba)){
                System.out.println("Indique el tipo de Prueba a realizar");
                System.out.println("(PCR - Análisis serológico - Test antígenos)");
                System.out.println("Recuerde que: \n·Entre dos PCR deben pasar al menos 15 días\n·Entre dos análisis serológicos deben pasar al menos 6 meses");
                String tipoPrueba = scanner.nextLine();
                switch(tipoPrueba){
                    case "PCR":
                    case "pcr":
                    case "Pcr":
                    
                    boolean puedePCR = true;
                    Enfermero enfermeroPruebaPCR = null;
                    Tecnico tecnicoPruebaPCR = null;

                    RegistroPrueba pcrPaciente = new RegistroPrueba(paciente.getDNI(), paciente.getNombre());
                    PCR pcr = new PCR();
                    pcrPaciente.setPrueba(pcr);
                    System.out.println("Introduzca el número de prueba");
                    System.out.println("Debe ser único para cada registro");
                    int numeroPruebaPCR;
                    try {
                        numeroPruebaPCR = Integer.parseInt(scanner.nextLine());
                    } catch (Exception e){
                        System.out.println("Error en la lectura del dato");
                        return;
                    }
                    for(Paciente p : pacientes){
                        ArrayList<RegistroPrueba> regPru = p.getHistorialPaciente().getRegistrosP();
                        for(RegistroPrueba rp : regPru){
                            if(rp.getNumeroRegistro() == numeroPruebaPCR){
                                System.out.println("Ya hay un registro con esa numeración");
                                return;
                            }
                        }
                    }
                    
                    pcrPaciente.setNumeroRegistro(numeroPruebaPCR);
                    System.out.println("Introduzca la fecha de la prueba");
                    System.out.println("IMPORTANTE -- FORMATO: AAAA-MM-DD");
                    String cadenaFechaPruebaPCR = scanner.nextLine();
                    LocalDate fechaPruebaPCR;
                    try {
                        fechaPruebaPCR = LocalDate.parse(cadenaFechaPruebaPCR);
                    } catch (Exception e){
                        System.out.println("Fecha no válida");
                        return;
                    }
                    ArrayList<RegistroPrueba> listaRegistrosPruebas = paciente.getHistorialPaciente().getRegistrosP();
                    // Se comprueba que el paciente puede realizarse otra prueba PCR en la fecha indicada, habiendo pasado los días correspondientes
                    for(RegistroPrueba registroP : listaRegistrosPruebas){
                        if(registroP.getPrueba() instanceof PCR 
                            && (fechaPruebaPCR.minusDays(pcr.getNumeroDiasEntrePruebas()).isBefore(registroP.getFecha()) 
                            || fechaPruebaPCR.minusDays(pcr.getNumeroDiasEntrePruebas()).isEqual(registroP.getFecha()))){
                                puedePCR = false;
                        } 
                    }
                    
                    if(puedePCR){
                        pcrPaciente.setFecha(fechaPruebaPCR);
                         
                        System.out.println("Listado de enfermeros disponibles para realizar la prueba");
                        listadoEnfermeros();
                        System.out.println("(Introduzca el DNI de la persona)");
                        String dniEnfermeroPCR = scanner.nextLine();
                        
                        // Se comprueba que el enfermero no haya realizado 5 o más pruebas diagnósticas en los últimos 7 días
                        for(Empleado empleado : empleados){
                            if(empleado instanceof Enfermero && empleado.getDNI().equalsIgnoreCase(dniEnfermeroPCR)){
                                ArrayList<RegistroPrueba> listaRegistrosPruebasEnfermero = empleado.getHistorialEmpleado().getRegistrosP();
                                for(RegistroPrueba registroPE : listaRegistrosPruebasEnfermero){
                                    if(ChronoUnit.DAYS.between(registroPE.getFecha(), fechaPruebaPCR) <= 5){
                                        numeroPruebasEnfermeroUltimaSemana++;
                                    }
                                 }
                                
                                 if(numeroPruebasEnfermeroUltimaSemana < 5){
                                 pcrPaciente.setEnfermero((Enfermero)empleado);
                                 enfermeroPruebaPCR = (Enfermero)empleado;
                                }
                             }
                        }
                        if(pcrPaciente.getEnfermero() !=null){
                            System.out.println("Listado de técnicos disponibles para realizar la prueba");
                            listadoTecnicos();
                            System.out.println("(Introduzca el DNI del tećnico)");
                            String dniTecnico = scanner.nextLine();
                            // Se comprueba que el técnico no haya realizado 4 o más pruebas diagnósticas en los últimos 7 días
                            for(Empleado empleado : empleados){
                                if(empleado instanceof Tecnico && empleado.getDNI().equalsIgnoreCase(dniTecnico)){
                                    ArrayList<RegistroPrueba> listaRegistrosPruebasTecnico = empleado.getHistorialEmpleado().getRegistrosP();
                                    for(RegistroPrueba registroPE : listaRegistrosPruebasTecnico){
                                     if(ChronoUnit.DAYS.between(registroPE.getFecha(), fechaPruebaPCR) <= 5){
                                         numeroPruebasTecnicoUltimaSemana++;
                                        }
                                    }
                                    
                                    if(numeroPruebasTecnicoUltimaSemana < 4){
                                    pcrPaciente.setTecnico((Tecnico)empleado);
                                    tecnicoPruebaPCR = (Tecnico)empleado;
                                    }
                                }
                            }
                            
                            if(pcrPaciente.getTecnico() != null){
                                paciente.getHistorialPaciente().getRegistrosP().add(pcrPaciente);
                                enfermeroPruebaPCR.getHistorialEmpleado().getRegistrosP().add(pcrPaciente);
                                tecnicoPruebaPCR.getHistorialEmpleado().getRegistrosP().add(pcrPaciente);
                                enfermeroPruebaPCR.getListaPacientesPruebas().add(paciente);
                                tecnicoPruebaPCR.getListaPacientesPruebas().add(paciente);
                                
                                System.out.println("Asignación exitosa");
                            } else {
                                if(numeroPruebasTecnicoUltimaSemana >= 4){
                                    System.out.println("Ese técnico no puede analizar más pruebas esta semana por motivos de seguridad");
                                } else {
                                    System.out.println("No hay ningún tecnico con ese DNI");
                                }
                            }
                        } else {
                            if(numeroPruebasEnfermeroUltimaSemana >= 5){
                                System.out.println("Ese enfermero no puede realizar más pruebas esta semana por motivos de seguridad");
                            } else {
                                System.out.println("No hay ningún enfermero con ese DNI");
                            }
                        }
                    } else {
                        System.out.println("Este paciente todavía no puede realizarse otra prueba PCR");

                    }
                        
                     break;
                     
                     case "Análisis Serológico":
                     case "análisis serológico":
                     case "Test serológico":
                     case "test serológico":
                     case "analisis serologico":
                     case "Analisis serologico":
                     
                    boolean puedeSerologico = true;
                    Enfermero enfermeroPruebaSerologico = null;
                    Tecnico tecnicoPruebaSerologico = null;
            
                    RegistroPrueba serologicoPaciente = new RegistroPrueba(paciente.getDNI(), paciente.getNombre());
                    AnalisisSerologico serologico = new AnalisisSerologico();
                    serologicoPaciente.setPrueba(serologico);
                    
                    System.out.println("Introduzca el número de prueba");
                    System.out.println("Debe ser único para cada registro");
                    int numeroPruebaSerologico;
                    try {
                        numeroPruebaSerologico = Integer.parseInt(scanner.nextLine());
                    } catch (Exception e){
                        System.out.println("Error en la lectura del dato");
                        return;
                    }
                    for(Paciente p : pacientes){
                        ArrayList<RegistroPrueba> regPru = p.getHistorialPaciente().getRegistrosP();
                        for(RegistroPrueba rp : regPru){
                            if(rp.getNumeroRegistro() == numeroPruebaSerologico){
                                System.out.println("Ya hay un registro con esa numeración");
                                return;
                            }
                        }
                    }
                    
                    serologicoPaciente.setNumeroRegistro(numeroPruebaSerologico);
                    
                    System.out.println("Introduzca la fecha de la prueba");
                    System.out.println("IMPORTANTE -- FORMATO: AAAA-MM-DD");
                    String cadenaFechaPruebaSerologico = scanner.nextLine();
                    LocalDate fechaPruebaSerologico;
                    try{
                        fechaPruebaSerologico = LocalDate.parse(cadenaFechaPruebaSerologico);
                    } catch (Exception e){
                        System.out.println("Fecha no válida");
                        return;
                    }
                    ArrayList<RegistroPrueba> listaRegistrosPruebaSerologico = paciente.getHistorialPaciente().getRegistrosP();
                    // Se comprueba que el paciente puede realizarse otra prueba de análisis serológico en la fecha indicada, habiendo pasado los meses correspondientes
                    for(RegistroPrueba registroP : listaRegistrosPruebaSerologico){
                          if(registroP.getPrueba() instanceof AnalisisSerologico && 
                          (fechaPruebaSerologico.minusMonths(serologico.getNumeroMesesEntrePruebas()).isBefore(registroP.getFecha()) || 
                          fechaPruebaSerologico.minusMonths(serologico.getNumeroMesesEntrePruebas()).isEqual(registroP.getFecha()))){
                                 puedeSerologico = false;
                             } 
                        }
                    if(puedeSerologico){
                        serologicoPaciente.setFecha(fechaPruebaSerologico);
                         
                        System.out.println("Listado de enfermeros disponibles para realizar la prueba");
                        listadoEnfermeros();
                        System.out.println("(Introduzca el DNI de la persona)");
                        String dniEnfermero = scanner.nextLine();
                        
                        // Se comprueba que el enfermero no haya realizado 5 o más pruebas diagnósticas en los últimos 7 días
                        for(Empleado empleado : empleados){
                            if(empleado instanceof Enfermero && empleado.getDNI().equalsIgnoreCase(dniEnfermero)){
                                ArrayList<RegistroPrueba> listaRegistrosPruebasEnfermero = empleado.getHistorialEmpleado().getRegistrosP();
                                for(RegistroPrueba registroPE : listaRegistrosPruebasEnfermero){
                                    if(ChronoUnit.DAYS.between(fechaPruebaSerologico, registroPE.getFecha()) <= 5){
                                        numeroPruebasEnfermeroUltimaSemana++;
                                    }
                                 }
                                
                                 if(numeroPruebasEnfermeroUltimaSemana < 5){
                                 serologicoPaciente.setEnfermero((Enfermero)empleado);
                                 enfermeroPruebaSerologico = (Enfermero)empleado;
                                }
                             }
                            }
                        if(serologicoPaciente.getEnfermero() !=null){
                            System.out.println("Listado de técnicos disponibles para realizar la prueba");
                            listadoTecnicos();
                            System.out.println("(Introduzca el DNI del tećnico)");
                            String dniTecnico = scanner.nextLine();
                            // Se comprueba que el técnico no haya realizado 4 o más pruebas diagnósticas en los últimos 7 días
                            for(Empleado empleado : empleados){
                                if(empleado instanceof Tecnico && empleado.getDNI().equalsIgnoreCase(dniTecnico)){
                                    ArrayList<RegistroPrueba> listaRegistrosPruebasTecnico = empleado.getHistorialEmpleado().getRegistrosP();
                                    for(RegistroPrueba registroPE : listaRegistrosPruebasTecnico){
                                     if(ChronoUnit.DAYS.between(fechaPruebaSerologico, registroPE.getFecha()) <= 5){
                                         numeroPruebasTecnicoUltimaSemana++;
                                        }
                                    }
                                    
                                    if(numeroPruebasTecnicoUltimaSemana < 4){
                                        serologicoPaciente.setTecnico((Tecnico)empleado);
                                        tecnicoPruebaSerologico = (Tecnico)empleado;
                                    }
                                }
                            }
                            
                            if(serologicoPaciente.getTecnico() != null){
                                paciente.getHistorialPaciente().getRegistrosP().add(serologicoPaciente);
                                enfermeroPruebaSerologico.getHistorialEmpleado().getRegistrosP().add(serologicoPaciente);
                                tecnicoPruebaSerologico.getHistorialEmpleado().getRegistrosP().add(serologicoPaciente);
                                enfermeroPruebaSerologico.getListaPacientesPruebas().add(paciente);
                                tecnicoPruebaSerologico.getListaPacientesPruebas().add(paciente);
                                
                                System.out.println("Asignación exitosa");
                            } else {
                                if(numeroPruebasTecnicoUltimaSemana >= 4){
                                    System.out.println("Ese técnico no puede analizar más pruebas esta semana por motivos de seguridad");
                                } else {
                                    System.out.println("No hay ningún tecnico con ese DNI");
                                }
                            }
                        } else {
                            if(numeroPruebasEnfermeroUltimaSemana >= 5){
                                System.out.println("Ese enfermero no puede realizar más pruebas esta semana por motivos de seguridad");
                            } else {
                                System.out.println("No hay ningún enfermero con ese DNI");
                            }
                        }
                    } else {
                        System.out.println("Este paciente todavía no puede realizarse otro análisis serológico");

                    }
                     
                     break;
                     
                     case "Test antígenos":
                     case "test antígenos":
                     case "Test antigenos":
                     case "test antigenos":
                     
                    Enfermero enfermeroPruebaAntigeno = null;
                    Tecnico tecnicoPruebaAntigeno = null;

                    RegistroPrueba antigenoPaciente = new RegistroPrueba(paciente.getDNI(), paciente.getNombre());
                    TestAntigeno antigeno = new TestAntigeno();
                    antigenoPaciente.setPrueba(antigeno);
                    
                    System.out.println("Introduzca el número de prueba");
                    System.out.println("Debe ser único para cada registro");
                    int numeroPruebaAntigeno;
                    try {
                        numeroPruebaAntigeno = Integer.parseInt(scanner.nextLine());
                    } catch (Exception e){
                        System.out.println("Error en la lectura del dato");
                        return;
                    }
                    for(Paciente p : pacientes){
                        ArrayList<RegistroPrueba> regPru = p.getHistorialPaciente().getRegistrosP();
                        for(RegistroPrueba rp : regPru){
                            if(rp.getNumeroRegistro() == numeroPruebaAntigeno){
                                System.out.println("Ya hay un registro con esa numeración");
                                return;
                            }
                        }
                    }
                    
                    antigenoPaciente.setNumeroRegistro(numeroPruebaAntigeno);
                    
                    System.out.println("Introduzca la fecha de la prueba");
                    System.out.println("IMPORTANTE -- FORMATO: AAAA-MM-DD");
                    String cadenaFechaPruebaAntigeno = scanner.nextLine();
                    LocalDate fechaPruebaAntigeno;
                    try {
                        fechaPruebaAntigeno = LocalDate.parse(cadenaFechaPruebaAntigeno);
                    } catch (Exception e){
                        System.out.println("Fecha no válida");
                        return;
                    }
                    antigenoPaciente.setFecha(fechaPruebaAntigeno);
                    
                    System.out.println("¿Tipo de test de antígenos? (Prueba rápida o Prueba clásica)");
                    String tipoPruebaAntigeno = scanner.nextLine();
                    antigeno.setTipoTestAntigeno(tipoPruebaAntigeno);
                    
                    System.out.println("Listado de enfermeros disponibles para realizar la prueba");
                    listadoEnfermeros();
                    System.out.println("(Introduzca el DNI de la persona)");
                    String dniEnfermero = scanner.nextLine();
                    
                    // Se comprueba que el enfermero no haya realizado 5 o más pruebas diagnósticas en los últimos 7 días
                    for(Empleado empleado : empleados){
                        if(empleado instanceof Enfermero && empleado.getDNI().equalsIgnoreCase(dniEnfermero)){
                            ArrayList<RegistroPrueba> listaRegistrosPruebasEnfermeroAntigeno = empleado.getHistorialEmpleado().getRegistrosP();
                            for(RegistroPrueba registroPE : listaRegistrosPruebasEnfermeroAntigeno){
                                 if(ChronoUnit.DAYS.between(registroPE.getFecha(), fechaPruebaAntigeno) <= 5){
                                        numeroPruebasEnfermeroUltimaSemana++;
                                  }
                            }
                            
                            if(numeroPruebasEnfermeroUltimaSemana < 5){
                                antigenoPaciente.setEnfermero((Enfermero)empleado);
                                enfermeroPruebaAntigeno = (Enfermero)empleado;
                            }
                        }
                    }
                    if(antigenoPaciente.getEnfermero() !=null){
                        System.out.println("Listado de técnicos disponibles para realizar la prueba");
                        listadoTecnicos();
                        System.out.println("(Introduzca el DNI del tećnico)");
                        String dniTecnico = scanner.nextLine();
                        // Se comprueba que el técnico no haya realizado 4 o más pruebas diagnósticas en los últimos 7 días
                        for(Empleado empleado : empleados){
                            if(empleado instanceof Tecnico && empleado.getDNI().equalsIgnoreCase(dniTecnico)){
                                ArrayList<RegistroPrueba> listaRegistrosPruebasTecnicoAntigeno = empleado.getHistorialEmpleado().getRegistrosP();
                                for(RegistroPrueba registroPE : listaRegistrosPruebasTecnicoAntigeno){
                                     if(ChronoUnit.DAYS.between(registroPE.getFecha(), fechaPruebaAntigeno) <= 5){
                                         numeroPruebasTecnicoUltimaSemana++;
                                        }
                                }
                                
                                if(numeroPruebasTecnicoUltimaSemana < 4){
                                antigenoPaciente.setTecnico((Tecnico)empleado);
                                tecnicoPruebaAntigeno = (Tecnico)empleado;
                                }
                            }
                        }
                            
                        if(antigenoPaciente.getTecnico() != null){
                            paciente.getHistorialPaciente().getRegistrosP().add(antigenoPaciente);
                            enfermeroPruebaAntigeno.getHistorialEmpleado().getRegistrosP().add(antigenoPaciente);
                            tecnicoPruebaAntigeno.getHistorialEmpleado().getRegistrosP().add(antigenoPaciente);
                            enfermeroPruebaAntigeno.getListaPacientesPruebas().add(paciente);
                            tecnicoPruebaAntigeno.getListaPacientesPruebas().add(paciente);
                                
                            System.out.println("Asignación exitosa");
                        } else {
                            if(numeroPruebasTecnicoUltimaSemana >= 4){
                                System.out.println("Ese técnico no puede analizar más pruebas esta semana por motivos de seguridad");
                            } else {
                                System.out.println("No hay ningún tecnico con ese DNI");
                            }
                        }
                        } else {
                            if(numeroPruebasEnfermeroUltimaSemana >= 5){
                                System.out.println("Ese enfermero no puede realizar más pruebas esta semana por motivos de seguridad");
                            } else {
                                System.out.println("No hay ningún enfermero con ese DNI");
                            }
                        }     
                     
                     break;
                }
            }
        }
    }
    
    /**
     * Con este método el empleado correspondiente introducirá los datos
     * del registro de prueba diagnóstica que requiera. En caso de que el
     * empleado sea administrador trabajará sobre la lista de todos los pacientes
     * del sistema, mientras que si es empleado, trabajará sobre su lista de pacientes
     * asignados
     * 
     * @param emp Empleado que introducirá los datos del registro
     */
    
    private void introducirDatosRegistroPrueba(Empleado emp){
        ArrayList<Paciente> listaPacientesPrueba;
        if(emp instanceof Administrador){
            listaPacientesPrueba = pacientes;
        } else {
            listaPacientesPrueba = emp.getListaPacientesPruebas();
        }
        
        System.out.println("Introduzca el DNI del paciente correspondiente al registro");
        
        for(Paciente paciente : listaPacientesPrueba){
            paciente.printPacienteInfo();
        }
        String dniPacienteRegistro = scanner.nextLine();
        
        
        for(Paciente paciente : listaPacientesPrueba){
            if(paciente.getDNI().equals(dniPacienteRegistro)){
                System.out.println("Listado de Registros del paciente:");
                ArrayList<RegistroPrueba> listaRegistrosPruebasPaciente = paciente.getHistorialPaciente().getRegistrosP();
                for(RegistroPrueba registroPrueba : listaRegistrosPruebasPaciente){
                    registroPrueba.printInfoRegistroPruebas();
                    System.out.println();
                }
                System.out.println("Introduzca la numeración de la prueba");
                int numeracionPrueba;
                try {
                    numeracionPrueba = Integer.parseInt(scanner.nextLine());
                } catch (Exception e){
                    System.out.println("Error en la lectura del dato");
                    return;
                }
                
                for(RegistroPrueba registroPrueba : listaRegistrosPruebasPaciente){
                    if(registroPrueba.getNumeroRegistro() == numeracionPrueba){
                        System.out.println("Introduzca el resultado de la prueba");
                        System.out.println("PCR o test antígenos -> Positivo/Negativo");
                        System.out.println("Análisis serológico -> Valor de 0 a 10");
                        if(registroPrueba.getPrueba() instanceof PCR || registroPrueba.getPrueba() instanceof TestAntigeno){
                            String cadenaResultado = scanner.nextLine();
                            if(cadenaResultado.equalsIgnoreCase("positivo")){
                                registroPrueba.getPrueba().setResultado(true);
                                registroPrueba.getPrueba().setRealizada(true);
                                return;
                            } else if (cadenaResultado.equalsIgnoreCase("negativo")){
                                registroPrueba.getPrueba().setResultado(false);
                                registroPrueba.getPrueba().setRealizada(true);
                                return;
                            } else {
                                System.out.println("Resultado no válido");
                                return;
                            }
                        } else if (registroPrueba.getPrueba() instanceof AnalisisSerologico){
                            String cadenaValorResultado = scanner.nextLine();
                            if(Integer.parseInt(cadenaValorResultado) >= 0 && Integer.parseInt(cadenaValorResultado) <= 10){
                                registroPrueba.getPrueba().setValorResultado(Integer.parseInt(cadenaValorResultado));
                                registroPrueba.getPrueba().setRealizada(true);
                                return;
                            } else {
                                System.out.println("El resultado debe estar entre 0 y 10");
                            }
                        }
                    }
                }
                System.out.println("Este paciente no tiene ningún registro de prueba diagnóstica con esa numeración");
                return;
            }
        }
        System.out.println("No hay ningún paciente con ese DNI");
    }
    
    /**
     * Con este método se incluye al paciente que tiene el DNI introducido
     * a la lista de espera de vacunación
     */
    
    private void incluirPacienteListaVacunación(){
        System.out.println("Lista de pacientes");
        listadoPacientes();
        System.out.println("(Introduzca el DNI del paciente para incluirlo en la lista de espera para vacunación)");
        String dniPaciente = scanner.nextLine();
        
        for(Paciente paciente : pacientes){
            if(paciente.getDNI().equalsIgnoreCase(dniPaciente)){
                if(!listaPacientesVacunacion.contains(paciente)){
                    listaPacientesVacunacion.add(paciente);
                    paciente.setPendientePrimeraVacuna(true);
                    return;
                }
                else {
                    System.out.println("Este paciente ya está incluido en la lista de vacunación");
                    return;
                }
            }
        }
        System.out.println("No hay ningún paciente con ese DNI");

    }
    
    /**
     * Con este método se asigna fecha, vacuna y enfermero al registro de
     * vacunas de un paciente (En caso de ser asignación de segunda dosis, solo
     * se asigna la fecha, ya que se mantiene la vacuna y el enfermero de la primera)
     * A lo largo el método se establecen las comprobaciones necesarias de prioridad,
     * primera o segunda dosis, o si el paciente está vacunado ya
     * 
     * Para asignar la vacunación será necesario que la lista de pacientes a la
     * espera de ser vacunados y la lista en la que se guarda el stock de vacunas
     * no estén vacías
     */
    private void asignarVacunas(){
        
        // Se comprueba que la lista de pacientes a la espera de ser vacunados no esté vacía
        if(listaPacientesVacunacion.isEmpty()){
            System.out.println("No hay pacientes en la lista de vacunación");
            return;
        }
        
        // Se comprueba que el stock de vacunas no esté vacío
        if(stockVacunas.isEmpty()){
            System.out.println("No hay vacunas en el stock");
            return;
        }
        System.out.println("Lista de pacientes que quieren vacunarse");
        System.out.println();
        for(Paciente paciente : listaPacientesVacunacion){
            paciente.printPacienteInfo();
            System.out.println();
        }
        System.out.println("(Introduzca el DNI del paciente para asignarle la vacunación)");
        String dniPacienteVacuna = scanner.nextLine();
        
        for(Paciente paciente : listaPacientesVacunacion){
            if(paciente.getDNI().equalsIgnoreCase(dniPacienteVacuna)){
                if(!paciente.getVacunado()){
                    if(paciente.getPrioritario()){
                        if(paciente.getPendientePrimeraVacuna()){
                            
                            Vacuna vacunaAleatoria = stockVacunas.get(numeroRandom.nextInt(stockVacunas.size()));
                            System.out.println("Vacuna a emplear: "+vacunaAleatoria.getNombreVacuna());
                            System.out.println("Lista de enfermeros disponibles:");
                            listadoEnfermeros();
                            System.out.println("(Introduzca el DNI del enfermero que va a ser asignado)");
                            String dniEnfermeroVacuna = scanner.nextLine();
                            
                            for(Empleado empleado : empleados){
                                if(empleado instanceof Enfermero && empleado.getDNI().equals(dniEnfermeroVacuna)){
                                    System.out.println("Introduzca la fecha para la vacunacion");
                                    System.out.println("IMPORTANTE -- FORMATO: AAAA-MM-DD");
                                    String cadenaFechaPrimeraVacuna = scanner.nextLine();
                                    LocalDate fechaPrimeraVacuna;
                                    try{
                                        fechaPrimeraVacuna = LocalDate.parse(cadenaFechaPrimeraVacuna);
                                    } catch (Exception e){
                                        System.out.println("Fecha no válida");
                                        return;   
                                    }
                                    
                                    paciente.getHistorialPaciente().getRegistroV().setVacuna(vacunaAleatoria);
                                    paciente.getHistorialPaciente().getRegistroV().setEnfermero((Enfermero)empleado);
                                    paciente.getHistorialPaciente().getRegistroV().setFechaPrimeraVacuna(fechaPrimeraVacuna);
                                    empleado.getListaPacientesVacunas().add(paciente);
                                    empleado.getHistorialEmpleado().getRegistrosV().add(paciente.getHistorialPaciente().getRegistroV());
                                    System.out.println("Fecha correctamente establecida");
                                    return;
                                }
                            }
                            System.out.println("Ningun enfermero con ese DNI");
                            return;
                            
                        } else if (paciente.getPendienteSegundaVacuna()){
                            if(paciente.getHistorialPaciente().getRegistroV().getVacuna().getNumeroDosis() != 1){
                                System.out.println("Enfermero que va a realizar la vacunación:");
                                System.out.println(paciente.getHistorialPaciente().getRegistroV().getEnfermero().getNombre());
                                System.out.println("Este paciente recibió la primera dosis el día: "+ paciente.getHistorialPaciente().getRegistroV().getFechaPrimeraVacuna());
                                System.out.println("Introduzca la fecha para la segunda dosis");
                                System.out.println("IMPORTANTE -- FORMATO: AAAA-MM-DD");
                                System.out.println("Recuerde que deben pasar 21 días entre cada dosis");
                                LocalDate fechaMinima = paciente.getHistorialPaciente().getRegistroV().getFechaPrimeraVacuna().plusDays(21);
                                System.out.println("La fecha mínima para la segunda dosis debe ser el día: "+ fechaMinima);
                                    
                                String cadenaFechaSegundaVacuna = scanner.nextLine();
                                LocalDate fechaSegundaVacuna; 
                                try {
                                    fechaSegundaVacuna = LocalDate.parse(cadenaFechaSegundaVacuna);
                                } catch (Exception e){
                                    System.out.println("Fecha no válida");
                                    return;   
                                }
                                while(fechaSegundaVacuna.isBefore(fechaMinima)){
                                    System.out.println("Recuerde que deben pasar 21 días entre cada dosis");
                                    System.out.println("La fecha mínima para la segunda dosis debe ser el día: "+ fechaMinima);
                                    cadenaFechaSegundaVacuna = scanner.nextLine();
                                    fechaSegundaVacuna = LocalDate.parse(cadenaFechaSegundaVacuna);
                                }
                                
                                paciente.getHistorialPaciente().getRegistroV().setFechaSegundaVacuna(fechaSegundaVacuna);
                                System.out.println("Fecha correctamente establecida");
                            }
                        }
                    } else {
                        for(Paciente pacienteP : listaPacientesVacunacion){
                            if(pacienteP.getPrioritario() && pacienteP.getPendientePrimeraVacuna()){
                                System.out.println("En estos momentos hay una persona con mayor prioridad a la espera de vacunarse");
                                return;
                            }
                        }
                        if(paciente.getPendientePrimeraVacuna()){
                            
                            Vacuna vacunaAleatoria = stockVacunas.get(numeroRandom.nextInt(stockVacunas.size()));
                            System.out.println("Vacuna a emplear: "+vacunaAleatoria.getNombreVacuna());
                            System.out.println("Lista de enfermeros disponibles:");
                            listadoEnfermeros();
                            System.out.println("(Introduzca el DNI del enfermero que va a ser asignado)");
                            String dniEnfermeroVacuna = scanner.nextLine();
                            
                            for(Empleado empleado : empleados){
                                if(empleado instanceof Enfermero && empleado.getDNI().equals(dniEnfermeroVacuna)){
                                    System.out.println("Introduzca la fecha para la vacunacion");
                                    System.out.println("IMPORTANTE -- FORMATO: AAAA-MM-DD");
                                    String cadenaFechaPrimeraVacuna = scanner.nextLine();
                                    LocalDate fechaPrimeraVacuna;
                                    try{
                                        fechaPrimeraVacuna = LocalDate.parse(cadenaFechaPrimeraVacuna);
                                    } catch (Exception e){
                                        System.out.println("Fecha no válida");
                                        return;   
                                    }
                                    
                                    paciente.getHistorialPaciente().getRegistroV().setVacuna(vacunaAleatoria);
                                    paciente.getHistorialPaciente().getRegistroV().setEnfermero((Enfermero)empleado);
                                    paciente.getHistorialPaciente().getRegistroV().setFechaPrimeraVacuna(fechaPrimeraVacuna);
                                    empleado.getListaPacientesVacunas().add(paciente);
                                    empleado.getHistorialEmpleado().getRegistrosV().add(paciente.getHistorialPaciente().getRegistroV());
                                    
                                    System.out.println("Fecha correctamente establecida");
                                    return;
                                }
                            }
                            System.out.println("Ningun enfermero con ese DNI");
                            return;
                            
                        } else if (paciente.getPendienteSegundaVacuna()){
                            if(paciente.getHistorialPaciente().getRegistroV().getVacuna().getNumeroDosis() != 1){
                                System.out.println("Enfermero que va a realizar la vacunación:");
                                System.out.println(paciente.getHistorialPaciente().getRegistroV().getEnfermero().getNombre());
                                System.out.println("Este paciente recibió la primera dosis el día: "+ paciente.getHistorialPaciente().getRegistroV().getFechaPrimeraVacuna());
                                System.out.println("Introduzca la fecha para la segunda dosis");
                                System.out.println("IMPORTANTE -- FORMATO: AAAA-MM-DD");
                                System.out.println("Recuerde que deben pasar 21 días entre cada dosis");
                                LocalDate fechaMinima = paciente.getHistorialPaciente().getRegistroV().getFechaPrimeraVacuna().plusDays(21);
                                System.out.println("La fecha mínima para la segunda dosis debe ser el día: "+ fechaMinima);
                                    
                                String cadenaFechaSegundaVacuna = scanner.nextLine();
                                LocalDate fechaSegundaVacuna;
                                try {
                                    fechaSegundaVacuna = LocalDate.parse(cadenaFechaSegundaVacuna);
                                } catch (Exception e){
                                    System.out.println("Fecha no válida");
                                    return;   
                                }
                                while(fechaSegundaVacuna.isBefore(fechaMinima)){
                                    System.out.println("Recuerde que deben pasar 21 días entre cada dosis");
                                    System.out.println("La fecha mínima para la segunda dosis debe ser el día: "+ fechaMinima);
                                    cadenaFechaSegundaVacuna = scanner.nextLine();
                                    fechaSegundaVacuna = LocalDate.parse(cadenaFechaSegundaVacuna);
                                }
                                System.out.println("Fecha correctamente establecida");
                                paciente.getHistorialPaciente().getRegistroV().setFechaSegundaVacuna(fechaSegundaVacuna);
                                return;
                            }
                        }
                    }
                } else {
                    System.out.println("Este paciente ya está vacunado");
                    return;
                }
            }
        }
        System.out.println("No hay ningún paciente con ese DNI");
    }
    
    /**
     * Con este método el empleado correspondiente introducirá los datos
     * del registro de vacuna que requiera. En caso de que el
     * empleado sea administrador trabajará sobre la lista de todos los pacientes
     * del sistema, mientras que si es empleado, trabajará sobre su lista de pacientes
     * asignados
     * 
     * @param emp Empleado que introducirá los datos del registro
     */
    
    private void actualizarDatosVacuna(Empleado emp){
        ArrayList<Paciente> listaPacientesParaVacunar;
        if(emp instanceof Administrador){
            listaPacientesParaVacunar = listaPacientesVacunacion;
        } else {
            listaPacientesParaVacunar = emp.getListaPacientesVacunas();
        }
        
        if(listaPacientesParaVacunar.isEmpty()){
            System.out.println("No hay pacientes en la lista de vacunación");
            return;
        }
        System.out.println("Lista de pacientes pendientes de vacunación o vacunados");
        for(Paciente paciente : listaPacientesParaVacunar){
             paciente.printPacienteInfo();   
        }
        System.out.println("Introduzca el DNI del paciente:");
        String dniPacienteVacuna = scanner.nextLine();
        
        for(Paciente paciente : listaPacientesParaVacunar){
            if(paciente.getDNI().equalsIgnoreCase(dniPacienteVacuna)){
                // Se comprueba que el paciente no esté ya completamente vacunado
                if(paciente.getVacunado()){
                    System.out.println("Este paciente ya ha sido vacunado, no hay que actualizar ningún dato relativo a su vacunación");
                    return;
                }
                if(paciente.getPendientePrimeraVacuna()){
                     if(paciente.getHistorialPaciente().getRegistroV().getFechaPrimeraVacuna() != null){
                        System.out.println("¿Recibió su dosis el paciente en la fecha indicada? ("+paciente.getHistorialPaciente().getRegistroV().getFechaPrimeraVacuna()+")");
                        System.out.println("Su respuesta debe ser: (SÍ/NO)");
                        String respuesta = scanner.nextLine();
                        if(respuesta.equalsIgnoreCase("si") || respuesta.equalsIgnoreCase("sí")){
                            if(paciente.getHistorialPaciente().getRegistroV().getVacuna().getNumeroDosis() > 1){
                                paciente.setPendientePrimeraVacuna(false);
                                paciente.setPendienteSegundaVacuna(true);
                                System.out.println("Paciente puesto a la espera de asignación de su segunda dosis");
                                return;
                            } else {
                                paciente.setPendientePrimeraVacuna(false);
                                paciente.setVacunado(true);
                                System.out.println("Paciente vacunado");
                                return;
                            }
                        } else if (respuesta.equalsIgnoreCase("no")){
                            paciente.getHistorialPaciente().getRegistroV().setFechaPrimeraVacuna(null);
                            paciente.getHistorialPaciente().getRegistroV().setEnfermero(null);
                            paciente.getHistorialPaciente().getRegistroV().setVacuna(null);
                            
                            System.out.println("Se borraron los datos del registro de vacuna asignado a este paciente");
                            System.out.println("Para volver a asignarle una fecha,enfermero y vacuna utilice la opción Asignar Vacunación");
                            return;
                        } else {
                            System.out.println("Respuesta no válida");
                            System.out.println("Su respuesta debe ser: (SÍ/NO)");
                            return;

                        }
                    } else {
                        System.out.println("Aún no se le ha asignado fecha para su primera dosis");
                    }
                } else if (paciente.getPendienteSegundaVacuna()){
                    if(paciente.getHistorialPaciente().getRegistroV().getFechaSegundaVacuna() != null){
                        System.out.println("¿Recibió su dosis el paciente en la fecha indicada? ("+paciente.getHistorialPaciente().getRegistroV().getFechaPrimeraVacuna()+")");
                        System.out.println("Su respuesta debe ser: (SÍ/NO)");
                        String respuesta = scanner.nextLine();
                        if(respuesta.equalsIgnoreCase("si") || respuesta.equalsIgnoreCase("sí")){
                            paciente.setPendienteSegundaVacuna(false);
                            paciente.setVacunado(true);
                            System.out.println("Paciente vacunado");
                            return;
                        } else if (respuesta.equalsIgnoreCase("no")){
                            paciente.getHistorialPaciente().getRegistroV().setFechaSegundaVacuna(null);
                            
                            System.out.println("Se borró la fecha de la asignación de la segunda dosis");
                            System.out.println("Para volver a asignarle una fecha utilice la opción Asignar Vacunación");
                            return;
                        } else {
                            System.out.println("Respuesta no válida");
                            System.out.println("Su respuesta debe ser: (SÍ/NO)");
                            return;

                        }
                    } else {
                        System.out.println("Aún no se le ha asignado fecha para su segunda dosis");
                        return;
                    }
                } 
             }
        }
    }
    
    /**
     * Método que imprime en pantalla la información del registro de vacuna
     * del paciente que se le pasa como parámetro. Se abarcan todos los casos 
     * posibles para la vacuna del paciente, ninguna, una ,dos o todas las dosis puestas
     * 
     * @param paciente Paciente del que se imprimirá la información de la vacunación
     */
    private void printInfoVacunaPaciente(Paciente paciente){  
        System.out.println("-----------------------------");
        System.out.println("      REGISTRO DE VACUNA     ");
        System.out.println("Paciente: "+ paciente.getNombre());
        System.out.println("DNI del paciente: " + paciente.getDNI());
        if(paciente.getPendientePrimeraVacuna()){
            if(paciente.getHistorialPaciente().getRegistroV().getFechaPrimeraVacuna() != null){
                System.out.println("Previsto vacunarse el día: " + paciente.getHistorialPaciente().getRegistroV().getFechaPrimeraVacuna());
                System.out.println("El enfermero que realizará la vacunación será: "+ paciente.getHistorialPaciente().getRegistroV(). getEnfermero().getNombre());
                System.out.println("La vacuna a utilizar será: " + paciente.getHistorialPaciente().getRegistroV(). getVacuna().getNombreVacuna());
            } else {
                System.out.println("Aún no se ha asignado la vacunación de su primera dosis");
            }
        } else if (paciente.getPendienteSegundaVacuna()){
            if(paciente.getHistorialPaciente().getRegistroV().getFechaSegundaVacuna() != null){
                System.out.println("Recibió la primera dosis el día: " + paciente.getHistorialPaciente().getRegistroV().getFechaPrimeraVacuna());
                System.out.println("Previsto vacunarse de la segunda dosis el día: " + paciente.getHistorialPaciente().getRegistroV().getFechaSegundaVacuna());
                System.out.println("El enfermero que realizará la vacunación será: "+ paciente.getHistorialPaciente().getRegistroV(). getEnfermero().getNombre());
                System.out.println("La vacuna a utilizar será: " + paciente.getHistorialPaciente().getRegistroV(). getVacuna().getNombreVacuna());
            } else {
                System.out.println("Recibió la primera dosis el día: " + paciente.getHistorialPaciente().getRegistroV().getFechaPrimeraVacuna());
                System.out.println("Aún no se ha asignado la fecha de vacunación de la segunda dosis");
                System.out.println("El enfermero que realizará la vacunación será: "+ paciente.getHistorialPaciente().getRegistroV(). getEnfermero().getNombre());
                System.out.println("La vacuna a utilizar será: " + paciente.getHistorialPaciente().getRegistroV(). getVacuna().getNombreVacuna());
            }
        } else if (paciente.getVacunado()){
                System.out.println("Recibió la primera dosis el día: " + paciente.getHistorialPaciente().getRegistroV().getFechaPrimeraVacuna());
                if(paciente.getHistorialPaciente().getRegistroV().getFechaSegundaVacuna() !=null){
                    System.out.println("Recibió la segunda dosis el día : " + paciente.getHistorialPaciente().getRegistroV().getFechaSegundaVacuna());
                }
                System.out.println("El enfermero que realizó la vacunación completa fue : "+ paciente.getHistorialPaciente().getRegistroV(). getEnfermero().getNombre());
                System.out.println("La vacuna utilizada fue: " + paciente.getHistorialPaciente().getRegistroV(). getVacuna().getNombreVacuna());
        } else {
                System.out.println("Este paciente no está en la lista de vacunación ");
            
        }
        System.out.println("-----------------------------");
    }
    
    /**
     * Método que comprobará en cada ejecución del bucle del menú prinicipal
     * si la cadena introducida es "salir" para ejecutar el fin de programa
     */
    private boolean quiereSalir(String entrada){
        
        if(entrada.equalsIgnoreCase("salir")){
            return true;
        } else {
            return false;
        }
    }
}
