
/**        
 * Clase que almacena la información de cada historial
 * de los pacientes
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class HistorialPaciente extends HistorialPersona
{
    private RegistroVacuna registroVacuna;
    
    /**
     * Constructor de los objetos de la clase HistorialPaciente
     */
    public HistorialPaciente(String dniPaciente, String nombrePaciente)
    {
        super();
        registroVacuna = new RegistroVacuna(dniPaciente, nombrePaciente);
    }
    
    /**
     * Devuelve el registro de vacuna del paciente
     * 
     * @return El registro de vacunación del paciente
     */
    public RegistroVacuna getRegistroV(){ return registroVacuna; }
}
