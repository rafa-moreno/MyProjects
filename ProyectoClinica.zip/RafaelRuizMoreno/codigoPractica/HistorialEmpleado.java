import java.util.ArrayList;
/**        
 * Clase que almacena la información de cada historial
 * de los empleados
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class HistorialEmpleado extends HistorialPersona
{
    private ArrayList<RegistroVacuna> registrosVacunas;
    
    /**
     * Constructor de los objetos de la clase HistorialEmpleado
     */
    public HistorialEmpleado(String dniPaciente, String nombrePaciente)
    {
        super();
        registrosVacunas = new ArrayList<>();
    }
    
    /**
     * Devuelve la lista de registros de vacunas
     * 
     * @return La lista de registros de vacunas del empleado
     */
    public ArrayList getRegistrosV(){ return registrosVacunas; }
}