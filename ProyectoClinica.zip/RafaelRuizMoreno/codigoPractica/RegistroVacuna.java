import java.time.LocalDate;

/**
 * Esta clase almacena la información que tienen los registros
 * de vacunas
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class RegistroVacuna extends Registro
{
    private Vacuna vacuna;
    private LocalDate fechaPrimeraVacuna;
    private LocalDate fechaSegundaVacuna;
    /**
     * Constructor para objetos de la clase RegistroVacuna
     */
    public RegistroVacuna(String dniPaciente, String nombrePaciente)
    {
        super(dniPaciente, nombrePaciente);
    }
    
    /**
     * Devuelve la vacuna asignada al registro
     * 
     * @return La vacuna asignada
     */
    public Vacuna getVacuna(){ return vacuna; }
    
    /**
     * Establece una nueva vacuna a registro
     * 
     * @param vacuna La nueva vacuna asignada al registro
     */
    public void setVacuna(Vacuna vacuna){ this.vacuna = vacuna; }
    
    /**
     * Establece una nueva fecha para la primera dosis de la vacuna
     * 
     * @param fecha La fecha para la primera dosis de la vacuna
     */
    public void setFechaPrimeraVacuna(LocalDate fecha){ fechaPrimeraVacuna = fecha; }
    
    /**
     * Establece una nueva fecha para la segunda dosis de la vacuna
     * 
     * @param fecha La fecha para la segunda dosis de la vacuna
     */
    public void setFechaSegundaVacuna(LocalDate fecha){ fechaSegundaVacuna = fecha; }
    
    /**
     * Devuelve la fecha de la primera dosis de la vacuna
     * 
     * @return La fecha de la primera dosis de la vacuna
     */
    public LocalDate getFechaPrimeraVacuna(){ return fechaPrimeraVacuna; }
    
    /**
     * Devuelve la fecha de la segunda dosis de la vacuna
     * 
     * @return La fecha de la segunda dosis de la vacuna
     */
    public LocalDate getFechaSegundaVacuna(){ return fechaSegundaVacuna;}
   
}
