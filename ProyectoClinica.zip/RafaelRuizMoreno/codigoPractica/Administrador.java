
/**
 * Esta clase representa a cada administrador de 
 * la clínica
 * 
 * @author Rafael Ruiz Moreno 
 * @version 0.1
 */
public class Administrador extends Empleado
{
    private String tipoEmpleado;
    
    /**
     * Constructor de los objetos de la clase Administrador
     */
    public Administrador(String dni, String nombre, int edad, boolean sexo)
    {
        super(dni, nombre, edad, sexo);
        tipoEmpleado = "Administrador";
    }
    
    /**
     * Devuelve el tipo de empleado
     * 
     * @return El tipo de empleado del administrador
     */
    public String getTipoEmpleado(){ return tipoEmpleado; }
    
    /**
     * Imprime en pantalla la información del empleado,
     * lo que incluye tipo de empleado y sus datos personales
     */
    public void printEmpleadoInfo(){
        System.out.println("Administrador: " + getPersonInfo());
    }
}
