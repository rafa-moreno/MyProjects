  
/**
 * Esta clase guarda la información de las pruebas
 * diagnósticas de tipo análisis serológico
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class AnalisisSerologico extends PruebaDiag
{
    private static final int NUMERO_MESES_ENTRE_PRUEBAS = 6;
    private int valorResultado;
    private boolean haPasadoEnfermedad;
    /**
     * Constructor de los objetos de la clase AnalisisSerologico
     */
    public AnalisisSerologico()
    {
        super("Análisis Serológico");
    }
    
    /**
     * Establece el valor de los resultados de la prueba, si procede
     * 
     * @param valorResultado El valor de los resultados de la prueba
     */
    public void setValorResultado(int valorResultado){ 
        this.valorResultado = valorResultado; 
        if(valorResultado > 2){
            setResultado(true);
        }
    }
    
    /**
     * Establece el valor del resultado, positivo si es true, sino será negativo
     * 
     * @param resultado Valor del resultado de la prueba
     */
    public void setResultado(boolean resultado){ haPasadoEnfermedad = resultado;}
    
    /**
     * Devuelve el valor del resultado de la prueba
     * 
     * @return El valor del resultado de la prueba
     */
    public int getValorResultado(){ return valorResultado; }
    
    /**
     * Devuelve el resultado de la prueba
     * 
     * @return Resultado de la prueba
     */
    public boolean getResultado(){ return haPasadoEnfermedad; }
    
    /**
     * Devuelve el número de meses que tienen que pasar entre cada prueba
     * 
     * @return Número de meses que tienen que pasar entre dos análisis serológico
     */
    public int getNumeroMesesEntrePruebas(){ return NUMERO_MESES_ENTRE_PRUEBAS; }
    
    /**
     * Imprime en pantalla la información de la prueba de análisis serológico
     */
    public void printInfoPrueba(){
        System.out.println("Análisis Serológico");
        System.out.println();
        System.out.println("Valor de anticuerpos del paciente(0-10): "+ getValorResultado());
        String resultadoPrueba;
        if(getResultado()){
                resultadoPrueba = "Ha pasado la enfermedad";
            } else {
                resultadoPrueba = "No ha pasado la enfermedad";
        }
        System.out.println("Resultado: " + resultadoPrueba);
    
    }
}

