
/**
 * Clase que define el conjunto de características
 * de cualquier persona dentro del sistema
 * @author Rafael Ruiz Moreno 
 * @version 0.1
 */
public class Persona
{
    // instance variables - replace the example below with your own
    private int edad;
    private boolean sexo;
    private String nombre, dni;

    /**
     * Constructor para los objetos de la clase Persona
     */
    public Persona(String dni, String nombre, int edad, boolean sexo)
    {
      this.nombre = nombre;
      this.edad = edad;
      this.dni = dni;
      this.sexo = sexo;
    }

    /**
     * Devuelve la edad de la persona
     * 
     * @return     la edad del paciente
     */
    public int getEdad() { return edad; }
    
    /**
     * Devuelve el sexo del paciente en forma de booleano
     * 
     * @return     el sexo del paciente (true = mujer, false = hombre)
     */
    public boolean getSexo() { return sexo; }
    
    /**
     * Devuelve el nombre de la persona
     * 
     * @return     el nombre de la persona
     */
    public String getNombre() { return nombre; }
    
    /**
     * Devuelve el DNI de la persona
     * 
     * @return    el DNI de la persona
     */
    public String getDNI(){ return dni;  }
    
    /**
     * Establece un nuevo valor para la edad de la persona
     * 
     * @param edad la nueva edad para la persona
     */
    public void setEdad(int edad){ this.edad = edad; }
    
    /**
     * Establece un nuevo nombre para la persona
     * 
     * @param nombre el nuevo nombre para la persona
     */
    public void setNombre(String nombre){ this.nombre = nombre; }
    
    /**
     * Establece un nuevo valor para el sexo de la persona
     * 
     * @param sexo el nuevo sexo para la persona
     */
    public void setSexo(boolean sexo){ this.sexo = sexo; }
    
    /**
     * Establece un nuevo valor para el DNI de la persona
     * 
     * @param dni el nuevo DNI de la persona
     */
    public void setDNI(String dni){ this.dni = dni; }
    
    /**
     *  Devuelve una cadena con la información de la persona
     *  
     *  @return la cadena de informacion
     */
    public String getPersonInfo(){
        String sexoCadena;
        if(!sexo){ sexoCadena = "Hombre"; } else { sexoCadena = "Mujer"; }
        return nombre + " || Edad: " + edad + " || Sexo: "+ sexoCadena + "\nDNI: " + dni;
    }
    
}
