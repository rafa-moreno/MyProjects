import java.util.ArrayList;
/**
 * Clase que almacena los datos que tendrá cada
 * historial de cualquier persona del sistema
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class HistorialPersona
{
    private ArrayList<RegistroPrueba> registrosPruebas;

    /**
     * Constructor de los objetos de la clase HistorialPersona
     */
    public HistorialPersona()
    {
        registrosPruebas = new ArrayList<>();
    }
    
    /**
     * Devuelve la lista de registros de pruebas diagnósticas de la persona
     * 
     * @return La lista de los registros de pruebas diagnósticas de la persona
     */
    public ArrayList getRegistrosP(){ return registrosPruebas; }
    
    /**
     * Imprime en pantalla los datos correspondientes a los registros de pruebas
     */
    public void printDatosHistorial(){
        if(!registrosPruebas.isEmpty()){
            for(RegistroPrueba registroP : registrosPruebas){
                registroP.printInfoRegistroPruebas();   
            }
        }
    }
}
