
/**
 * Clase que guarda la información de la vacuna Moderna
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class VacunaModerna extends Vacuna
{
    private static final int NUMERO_DOSIS = 2;

    /**
     * Constructor de los objetos de la clase VacunaModerna
     */
    public VacunaModerna()
    {
        super("Moderna");
    }
    
    /**
     * Devuelve el número de dosis de la vacuna
     * 
     * @return Número de dosis de la vacuna
     */
    public int getNumeroDosis(){ return NUMERO_DOSIS; }
}
