
/**
 * Esta clase representa a cada paciente que sea 
 * dado de alta en la clínica
 * @author Rafael Ruiz Moreno 
 * @version 0.1
 */
public class Paciente extends Persona implements Comparable<Paciente>
{
    private boolean prioritarioVacunacion;
    private boolean pendientePrimeraVacuna;
    private boolean pendienteSegundaVacuna;
    private boolean vacunado;
    private HistorialPaciente historialPaciente;
    /**
     * Constructor de los objetos de la clase Paciente
     */
    public Paciente(String dni, String nombre, int edad, boolean sexo)
    {
        super(dni, nombre, edad, sexo);
        if(edad >= 65){ prioritarioVacunacion = true; } else { prioritarioVacunacion = false;}
        historialPaciente = new HistorialPaciente(dni, nombre);
        pendientePrimeraVacuna = false;
        pendienteSegundaVacuna = false;
        vacunado = false;
    }

    /**
     * Imprime por pantalla la informacion relativa al
     * paciente
     */
    public void printPacienteInfo()
    {
        System.out.println("Paciente: " + getPersonInfo());
    }
    
    /**
     * Devuelve el historial del paciente
     * 
     * return El historial del paciente
     */
    public HistorialPaciente getHistorialPaciente(){ return historialPaciente;}
    
    /**
     * Establece una edad para el paciente
     * 
     * @param edad La nueva edad del paciente
     */
    public void setEdad(int edad){ 
        setEdad(edad); 
        if(edad >= 65){ prioritarioVacunacion = true; } else { prioritarioVacunacion = false;}
    }
    
    /**
     * Devuelve si el paciente es prioritario o no
     * 
     * @return true si es prioritario, false si no lo es
     */
    public boolean getPrioritario(){ return prioritarioVacunacion; }
    
    /**
     * Devuelve si el paciente está vacunado o no
     * 
     * @return true si está vacunado, false si no lo está
     */
    public boolean getVacunado(){ return vacunado; }
    
    /**
     * Establece si el paciente está vacunado
     * 
     * @param vacunado El estado de vacunado o no, del paciente
     */
    public void setVacunado(boolean vacunado){ this.vacunado = vacunado; }
    
    /**
     * Devuelve si el paciente está pendiente de su primera dosis
     * 
     * @return True si está pendiente de su primera dosis, false si no
     */
    public boolean getPendientePrimeraVacuna(){ return pendientePrimeraVacuna;}
    
    /**
     * Establece si el paciente está pendiente o no de su primera dosis
     * 
     * @param pendiente El parámetro que determina si está pendiente de primera dosis o no
     */
    public void setPendientePrimeraVacuna(boolean pendiente){ pendientePrimeraVacuna = pendiente;}
    
    /**
     * Devuelve si el paciente está pendiente de su segunda dosis
     * 
     * @return True si está pendiente de su segunda dosis, false si no
     */
    public boolean getPendienteSegundaVacuna(){ return pendienteSegundaVacuna;}
    
    /**
     * Establece si el paciente está pendiente o no de su segunda dosis
     * 
     * @param pendiente El parámetro que determina si está pendiente de segunda dosis o no
     */
    public void setPendienteSegundaVacuna(boolean pendiente){ pendienteSegundaVacuna = pendiente;}
    
    /**
     * Método que se empleará para comparar a los pacientes en función de su edad
     */
    public int compareTo(Paciente p){
        return p.getEdad() - getEdad();
    }
}
