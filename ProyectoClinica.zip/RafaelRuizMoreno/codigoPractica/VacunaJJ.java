
/**
 * Clase que guarda la información de la vacuna JohnsonAndJohnson
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class VacunaJJ extends Vacuna
{
    private static final int NUMERO_DOSIS = 1;

    /**
     * Constructor de los objetos de la clase VacunaJJ
     */
    public VacunaJJ()
    {
        super("Johnson&Johnson");
    }
    
    /**
     * Devuelve el número de dosis de la vacuna
     * 
     * @return Número de dosis de la vacuna
     */
    public int getNumeroDosis(){ return NUMERO_DOSIS; }
}
