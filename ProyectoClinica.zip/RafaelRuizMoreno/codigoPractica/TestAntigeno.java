
/**
 * Esta clase guarda la información de las pruebas
 * diagnósticas de tipo test antígenos
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class TestAntigeno extends PruebaDiag
{
    private boolean resultado;
    private String tipoTestAntigeno;
    /**
     * Constructor de ojbetos de la clase TestAntigeno
     */
    public TestAntigeno()
    {
        super("Test Antigenos");
    }
    
    /**
     * Establece el valor del resultado, positivo si es true, sino será negativo
     * 
     * @param resultado Valor del resultado de la prueba
     */
    public void setResultado(boolean resultado){ this.resultado = resultado; }
    
    /**
     * Devuelve el resultado de la prueba
     * 
     * @return Resultado de la prueba
     */
    public boolean getResultado(){ return resultado; }
    
    /**
     * Establece el tipo de test de antígenos
     * 
     * @param tipo El tipo de test de antígenos
     */
    public void setTipoTestAntigeno(String tipo){ tipoTestAntigeno = tipo; }
    
    /**
     * Devuelve el tipo de test de antígenos
     * 
     * @return el tipo de test de antígenos
     */
    public String getTipoTestAntigeno(){ return tipoTestAntigeno; }
    
    /**
     * Imprime en pantalla la información de la prueba de test de antígenos
     */
    public void printInfoPrueba(){
        System.out.println("Test Antígenos: " + tipoTestAntigeno);
        System.out.println();
        String resultadoPrueba;
        if(getResultado()){
            resultadoPrueba = "Positivo";
            } else {
                resultadoPrueba = "Negativo";
            }
        System.out.println("Resultado: " + resultadoPrueba);
    }
}
