
/**
 * Esta clase guarda la información de las pruebas
 * diagnósticas de tipo PCR
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class PCR extends PruebaDiag
{
    private static final int NUMERO_DIAS_ENTRE_PRUEBAS = 15;
    private boolean resultado;
    /**
     * Constructor de los objetos de la clase PCR
     */
    public PCR()
    {
        super("PCR");
    }
    
    /**
     * Establece el valor del resultado, positivo si es true, sino será negativo
     * 
     * @param resultado Valor del resultado de la prueba
     */
    public void setResultado(boolean resultado){ this.resultado = resultado; }
    
    /**
     * Devuelve el resultado de la prueba
     * 
     * @return Resultado de la prueba
     */
    public boolean getResultado(){ return resultado; }
    
    /**
     * Devuelve el número de días que tienen que pasar entre cada prueba
     * 
     * @return Número de días que tienen que pasar entre dos pruebas PCR
     */
    public int getNumeroDiasEntrePruebas(){ return NUMERO_DIAS_ENTRE_PRUEBAS; }
    
    /**
     * Imprime en pantalla la información de la prueba PCR
     */
    public void printInfoPrueba(){
        System.out.println("PCR");
        System.out.println();
        String resultadoPrueba;
        if(getResultado()){
            resultadoPrueba = "Positivo";
            } else {
                resultadoPrueba = "Negativo";
            }
        System.out.println("Resultado: " + resultadoPrueba);
    }
}
