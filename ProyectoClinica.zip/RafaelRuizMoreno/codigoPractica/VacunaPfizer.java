
/**
 * Clase que guarda la información de la vacuna Pfizer
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class VacunaPfizer extends Vacuna
{
    private static final int NUMERO_DOSIS = 2;

    /**
     * Constructor de los objetos de la clase VacunaPfizer
     */
    public VacunaPfizer()
    {
        super("Pfizer");
    }
    
    /**
     * Devuelve el número de dosis de la vacuna
     * 
     * @return Número de dosis de la vacuna
     */
    public int getNumeroDosis(){ return NUMERO_DOSIS; }
}
