
/**
 * Esta clase representa a cada enfermero de 
 * la clínica
 * @author Rafael Ruiz Moreno 
 * @version 0.1
 */
public class Enfermero extends Empleado
{
      private String tipoEmpleado;
    
    /**
     * Constructor de los objetos de la clase Enfermero
     */
    public Enfermero(String dni, String nombre, int edad, boolean sexo)
    {
        super(dni, nombre, edad, sexo);
        tipoEmpleado = "Enfermero";
    }
    
    /**
     * Devuelve el tipo de empleado
     * 
     * @return El tipo de empleado del enfermero
     */
    public String getTipoEmpleado(){ return tipoEmpleado; }
    
    /**
     * Imprime en pantalla la información del empleado,
     * lo que incluye tipo de empleado y sus datos personales
     */
    public void printEmpleadoInfo(){
        System.out.println("Enfermero: " + getPersonInfo());
     }
}