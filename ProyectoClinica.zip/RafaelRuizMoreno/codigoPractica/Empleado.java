import java.util.ArrayList;

/**
 * Esta clase representa a cada empleado de 
 * la clínica
 * @author Rafael Ruiz Moreno 
 * @version 0.1
 */
abstract class Empleado extends Persona
{
    private HistorialEmpleado historialEmpleado;
    private ArrayList<Paciente> listaPacientesAsignadosPruebas;
    private ArrayList<Paciente> listaPacientesAsignadosVacunas;
    /**
     * Constructor para los objetos de la clase Empleado
     */
    public Empleado(String dni, String nombre, int edad, boolean sexo)
    {
        super(dni, nombre, edad, sexo);
        historialEmpleado = new HistorialEmpleado(dni, nombre);
        listaPacientesAsignadosPruebas = new ArrayList<>();
        listaPacientesAsignadosVacunas = new ArrayList<>();
    }
    
    /**
     * Devuelve el tipo de empleado
     * 
     * @return El tipo de empleado
     */
    abstract public String getTipoEmpleado();
    
    /**
     * Imprime en pantalla la información del empleado,
     * lo que incluye tipo de empleado y sus datos personales
     */
    abstract public void printEmpleadoInfo();
    
    /**
     * Devuelve la lista de pacientes asignados para las pruebas diagnósticas
     * 
     * @return La lista de pacientes asignados para pruebas diagnósticas
     */
    public ArrayList getListaPacientesPruebas(){ return listaPacientesAsignadosPruebas;}
    
    /**
     * Devuelve la lista de pacientes asignados para las vacunas
     * 
     * @return La lista de pacientes asignados para vacunas
     */
    public ArrayList getListaPacientesVacunas(){ return listaPacientesAsignadosVacunas;}
    
    /**
     * Devuelve el historial del empleado
     * 
     * @return El historial el empleado
     */
    public HistorialEmpleado getHistorialEmpleado(){ return historialEmpleado;}
    
    /**
     * Establece un nuevo historial para el empleado
     * 
     * @param he El nuevo historial para el empleado
     */
    public void setHistorialEmpleado(HistorialEmpleado he){ historialEmpleado = he;}
    
}
