
/**
 * Esta clase almacena la información común a todas las
 * pruebas diagnósticas
 * 
 * @author Rafael Ruiz Moreno 
 * @version 0.1
 */
abstract class PruebaDiag
{
    private String nombrePrueba;
    boolean realizada; 
    /**
     * Constructor para los objetos de la clase PruebaDiag
     */
    public PruebaDiag(String nombrePrueba)
    {
        this.nombrePrueba = nombrePrueba;
        realizada = false;
    }
    
    /**
     * Devuelve el nombre de la prueba
     * 
     * @return El nombre de la prueba diagnóstica
     */
    public String getNombrePrueba(){ return nombrePrueba;}
    
    /**
     * Establece si la prueba ha sido realizada o no
     * 
     * @param realizada Parámetro que si su valor es true, establecerá la prueba como realizada
     */
    public void setRealizada(boolean realizada){ this.realizada = realizada; }
    
    /**
     * Devuelve la variable que determina si la prueba ha sido realizada o no
     * Si es true, la prueba se habrá realizado
     * 
     * @return true si ha sido realizada, false si no
     */
    public boolean getRealizada(){ return realizada; }
    
    /**
     * Establece el valor de los resultados de la prueba, si procede
     * 
     * @param valorResultado El valor de los resultados de la prueba
     */
    public void setValorResultado(int valorResultado){}
    
    /**
     * Imprime en pantalla la información de la prueba
     */
    abstract void printInfoPrueba();
    
    /**
     * Establece el valor del resultado, positivo si es true, sino será negativo
     * 
     * @param resultado Valor del resultado de la prueba
     */
    abstract void setResultado(boolean resultado);
    
    /**
     * Devuelve el resultado de la prueba
     * 
     * @return Resultado de la prueba
     */
    abstract boolean getResultado();
    
}
