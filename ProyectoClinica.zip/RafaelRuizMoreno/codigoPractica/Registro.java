import java.time.LocalDate;

/**
 * Esta clase almacena la información acerca de los datos comunes a los tipos
 * de registro que tendremos en nuestro sistema, tanto de pruebas diagnósticas
 * como de vacunas
 * 
 * @author Rafael Ruiz Moreno
 * @version 0.1
 */
public class Registro
{
    private String dniPaciente;
    private String nombrePaciente;
    private Enfermero enfermero;
    /**
     * Constructor para los objetosde la clase Registro
     */
    public Registro(String dniPaciente, String nombrePaciente)
    {
        this.dniPaciente = dniPaciente;
        this.nombrePaciente = nombrePaciente;
    }

    /**
     * Devuelve el paciente asignado al registro
     * 
     * @return    DNI del paciente asignado
     */
    public String getDniPaciente()  {  return dniPaciente;  }
    
    /**
     * Devuelve el nombre del paciente asignado al registro
     * 
    * @return     Nombre del paciente asignado
     */
    public String getNombrePaciente() { return nombrePaciente; }
    
    /**
     * Devuelve el enfermero asignado al registro
     * 
     * @return     Enfermero asignado al registro
     */
    public Empleado getEnfermero()  {  return enfermero;  }
    
    /**
     * Establece un nuevo DNI de paciente en el registro
     * 
     * @param dniPaciente El nuevo paciente del registro
     */
    public void setDniPaciente(String dniPaciente)  { this.dniPaciente = dniPaciente;  }
    
    /**
     * Establece un nuevo enfermero en el registro
     * 
     * @param enfermero El nuevo enfermero del registro
     */
    public void setEnfermero(Enfermero enfermero)  { this.enfermero = enfermero;  }
    
}
